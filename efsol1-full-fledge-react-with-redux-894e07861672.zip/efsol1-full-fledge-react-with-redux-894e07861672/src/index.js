/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import {
    Route,
    BrowserRouter as Router,
    Switch
} from 'react-router-dom';

import { Provider } from "react-redux";
import store from "./redux/index";

/*=========================================================*/
/*===================== CLIENT PAGES ======================*/
import Home from './client_pages/home';
import BoatDetail from './client_pages/boat_detail';
import Inventory from './client_pages/inventory';
import Contact from './client_pages/contact';
import LoanCalculator from './client_pages/loan_calculator';
import PartsRequest from './client_pages/parts_request';
import NewsEvents from './client_pages/news_events';
import ArticleDetail from './client_pages/article_detail';
import EventDetail from './client_pages/event_detail';
import Service from './client_pages/service';

/*=========================================================*/
/*===================== ADMIN PAGES ======================*/
import AdminHome from './admin_pages/home';
import AdminLogin from './admin_pages/login';

/*=========================================================*/
/*===================== 404 PAGE ======================*/
import Client404 from './client_pages/404/notfound';
import Admin404 from './admin_pages/404/notfound';

const routing = (
    <Provider store={store}>
        <Router>
            <Switch>
            {/*=========================================================*/}
            {/*===================== CLIENT ROUTES =====================*/}
            <Route exact path="/" component={Home}/>
            <Route exact path="/boat-detail" component={BoatDetail}/>
            <Route exact path="/inventory" component={Inventory}/>
            <Route exact path="/contact" component={Contact}/>
            <Route exact path="/loan_calculator" component={LoanCalculator}/>
            <Route exact path="/parts_request" component={PartsRequest}/>
            <Route exact path="/news_events" component={NewsEvents}/>
            <Route exact path="/article_detail" component={ArticleDetail}/>
            <Route exact path="/event_detail" component={EventDetail}/>
            <Route exact path="/service" component={Service}/>
    
            {/*=========================================================*/}
            {/*===================== ADMIN ROUTES =====================*/}
            <Route
                path="/admin"
                render={({ match: { url } }) => (
                    <Switch>
                        <Route exact path={`${url}/`} component={AdminHome} />
                        <Route exact path={`${url}/login/`} component={AdminLogin}/>
                        {/*================== ADMIN 404 =================*/}
                        <Route component={Admin404}/>
                    </Switch>
                )}
            />
    
            {/*======================= CLIENT 404 ========================*/}
            <Route component={Client404}/>
        </Switch>
        </Router>
    </Provider>
);
ReactDOM.render(routing, document.getElementById('root'));
