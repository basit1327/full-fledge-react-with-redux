/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2020-12-25
 */

import {createStore, combineReducers} from 'redux';
import headerMenuReducer from './reducers/headerMenuReducer';
import adminReducer from './reducers/adminReducer';

const appInitialState = {
	movies : [
		{ name: "TERMINATOR 2" }
	],
	headerMenu : [],
	featuredBoats : [],
	news : [],
	adminState : {}
}

const reducer = combineReducers({headerMenuReducer,adminReducer});

const store = createStore(reducer,appInitialState);

export default store;

