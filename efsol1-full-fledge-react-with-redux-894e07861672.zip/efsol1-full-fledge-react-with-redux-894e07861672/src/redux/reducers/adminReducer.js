/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2020-12-25
 */

import {PAGE_CHANGE} from '../actions/adminAction';
import admin_pages from '../../utils/admin_pages';

const initialState = {selectedPage : admin_pages[0].childs[0].key}

const adminReducer = (state = initialState, {type, payload}) => {
	switch(type) {
		case PAGE_CHANGE:
			return {
				...state,
				selectedPage:payload
			}
		default :
			return state
	};
};
export default adminReducer;
