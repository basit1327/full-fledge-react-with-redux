/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2020-12-25
 */

import {HEADER_MENU_UPDATE} from '../actions/headerMenuAction';

const initialState = {headerMenu : []}

const headerMenuReducer = (state = initialState, {type, payload}) => {
	switch(type) {
		case HEADER_MENU_UPDATE:
			return {
				...state,
				headerMenu:payload
			}
		default :
			return state
	};
};
export default headerMenuReducer;
