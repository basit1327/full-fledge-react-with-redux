/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2020-12-25
 */

export const PAGE_CHANGE = "PAGE_CHANGE";

export const updateAdminPage = content => ({
	type: PAGE_CHANGE,
	payload: content
});
