/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

export default [
	{
		category:'Products',
		childs:[
			{key:'AddProduct',val:'Add New',icon:'fa fa-plus-square-o fa-icon'},
			{key:'ListProduct',val:'List Products',icon:'fa fa-list fa-icon'},
		]
	},
	{
		category:'Boats',
		childs:[
			{key:'AddBoat',val:'New',icon:'fa fa-plus-square-o fa-icon'},
			{key:'ListBoat',val:'List',icon:'fa fa-list fa-icon'},
		]
	},
	{
		category:'Events',
		childs:[
			{key:'AddEvent',val:'New',icon:'fa fa-plus-square-o fa-icon'},
			{key:'ListEvent',val:'List',icon:'fa fa-list fa-icon'},
		]
	},
	{
		category:'Users',
		childs:[
			{key:'AddUser',val:'New',icon:'fa fa-user-plus fa-icon'},
			{key:'ListUser',val:'Edit',icon:'fa fa-pencil-square-o fa-icon'},
			{key:'EditMyAccount',val:'My Account',icon:'fa fa-user-circle-o fa-icon'},
		]
	},
	{
		category:'Email',
		childs:[
			{key:'EmailNotification',val:'Email Notification',icon:'fa fa-mail-reply-all fa-icons'},
			{key:'EmailTemplateSetting',val:'Template Setting',icon:'fa fa-cog fa-icon'},
			{key:'EmailSetting',val:'Email Setting',icon:'fa fa-envelope fa-icon'},
		]
	},
	{
		category:'Setting',
		childs:[
			{key:'GeneralSetting',val:'General Setting',icon:'fa fa-cog fa-icon'},
			{key:'MenuSetting',val:'Menu Setting',icon:'fa fa-cog fa-icon'},
		]
	},
];
