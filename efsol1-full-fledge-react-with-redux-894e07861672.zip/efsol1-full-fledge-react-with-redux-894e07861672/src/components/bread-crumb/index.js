/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from "react";
import './style.css';

class BreadCrumb extends React.Component {
	
	renderNavigation(){
		let links = []
		links.push(<a href={'/'}>Home / </a>)
		
		for ( const [index, element] of this.props.navigation.entries() ) {
			if(index==this.props.navigation.length-1){
				links.push(
					<a href={'#'}>{element.title}</a>
				)
			}
			else {
				links.push(
					<a href={element.link}>{element.title+' / '}</a>
				)
			}
		}
		return links
	}
	
	render() {
		return (
			<React.Fragment>
				<div className="row">
					<div className="col-12">
						<div className="breadcram">
							<span>{this.renderNavigation()}</span>
						</div>
						<div className="parts_title">
							<h1 style={!this.props.title?{display:'None'}:{}}>{this.props.title}</h1>
							<p>{this.props.description}</p>
						</div>
					</div>
				</div>
			</React.Fragment>
		);
	}
}

export default BreadCrumb;
