/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from "react";

class FeaturedBoat extends React.Component {
	render() {
		return (
			<React.Fragment>
				<div className="col-lg-3 col-md-6 col-sm-6 col-12">
					<div className="wrapper">
						<div className="image_frame">
							<a href={'/boat-detail?id='+this.props._id}>
								<img src={this.props.productImage?this.props.productImage:"assets/images/placeholder.jpg"} alt="Boats"/>
							</a>
							<p className="View_boat">
								<a className="" href="#">Call For Pricing </a>
							</p>
						</div>
						<div className="boat_content">
							<a href={'/boat-detail?id='+this.props._id}><h3>{this.props.year} {this.props.make} {this.props.model}</h3></a>
							<ul>
								<li><span>Year:</span> <strong>{this.props.year}</strong></li>
								<li><span>Make:</span> <strong>{this.props.make}</strong></li>
								<li><span>Model:</span> <strong>{this.props.model}</strong></li>
								<li><span>Lenght:</span> <strong>{this.props.length}</strong></li>
							</ul>
						</div>
					</div>
				</div>
			</React.Fragment>
		);
	}
}

export default FeaturedBoat;
