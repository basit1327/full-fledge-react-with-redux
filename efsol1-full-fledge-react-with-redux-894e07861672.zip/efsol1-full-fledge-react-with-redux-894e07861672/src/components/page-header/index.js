/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from "react";
import { userApiCall } from '../../utils/ajax_request';
import Swal from 'sweetalert2'
import {connect} from 'react-redux';
import {updateHeaderMenu} from '../../redux/actions/headerMenuAction';

class PageHeader extends React.Component {
	
	async componentWillMount () {
		this.getHeaderMenuData()
	}
	
	async getHeaderMenuData(){
		try{
			let x = localStorage.getItem('header_menu');
			if(x){
				x = JSON.parse(x);
				this.props.updateHeaderMenu(x)
			}
			else {
				let res = await userApiCall('get_header_menu');
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 && res.hasOwnProperty('data') ) {
						localStorage.setItem('header_menu',JSON.stringify(res.data))
						this.props.updateHeaderMenu( res.data)
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
		}
		catch ( e ){
			console.log(e);
		}
	}
	
	renderMenuItems(){
		let items = [];
		for ( const [index, element] of this.props.headerMenu.entries() ) {
			if(element.children.length>0){
				items.push(
					<li key={index} className="dropdown">
						<a className="dropdown-toggle" data-toggle="dropdown" href={element.link}>{element.title}
							<span className="caret"></span></a>
						<ul className="dropdown-menu">
							{/*Render 2nd level submenu*/}
							{this.render2ndLevelSubmenuItems(element.children)}
						</ul>
					</li>
				)
			}else {
				items.push(
					<li key={index}><a href={element.link}>{element.title}</a></li>
				)
			}
		}
		return items;
	}
	
	render2ndLevelSubmenuItems(children){
		let items = [];
		for ( const [index, element] of children.entries() ){
			items.push(<li key={index}><a href={element.link}>{element.title}</a></li>)
		}
		return items;
	}
	
	render() {
		return (
			<React.Fragment>
				<header className="section-strt">
					<div className="container">
						<nav className="navbar">
							<div className="top-head-sec">
								<div className="row">
									<div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
										<div className="general-numbers">
											<span><a href="#">MESA: 480.986.8898</a></span>
											<span><a href="#">LAKE HAVASU CITY: 928.733.7034</a></span>
										</div>
									</div>
									<div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
										<div className="socail_icons pull-right ">
											<ul>
												<li>
													<span><a href="#"><i hidden="hidden">Facebook</i><i className="fa fa-facebook-f"></i></a></span>
													<span><a href="#"><i hidden="hidden">Instagram</i><i className="fa fa-instagram"></i></a></span>
													<span><a href="#"><i hidden="hidden">Youtube</i><i className="fa fa-youtube"></i></a></span>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							<div className="sec-head">
								<div className="row">
									<div className="col-lg-3 col-md-12 col-sm-12 col-xs-12">
										<div className="navbar-header">
											<a className="navbar-brand" href="/">
												<img src="assets/images/wolf-site-logo.png"/>
											</a>
										</div>
									</div>
									<div className="col-lg-9 col-md-12 col-sm-12 col-xs-12">
										<div className="navbar-header">
											<button type="button" className="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
												<span className="icon-bar"></span>
												<span className="icon-bar"></span>
												<span className="icon-bar"></span>
											</button>
										</div>
										<div className="collapse navbar-collapse" id="myNavbar">
											<ul className="nav navbar-nav" >
												{this.renderMenuItems()}
											</ul>
											<ul className="nav navbar-nav navbar-right">
												<li><a href="#">Get Financing</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</nav>
					</div>
				</header>
			</React.Fragment>
		);
	}
}

function MapStateToProps(state) {
	return {headerMenu : state.headerMenuReducer.headerMenu}
}

function MapDispatchToProps() {
	return {
		updateHeaderMenu
	};
}

export default connect(MapStateToProps,MapDispatchToProps())(PageHeader);
