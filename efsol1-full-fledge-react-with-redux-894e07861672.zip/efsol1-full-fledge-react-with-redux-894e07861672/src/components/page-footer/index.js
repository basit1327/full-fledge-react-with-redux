/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from "react";

class PageFooter extends React.Component {
	render() {
		return (
			<React.Fragment>
				<footer className="footer-section section-strt">
					<div className="container">
						<div className="row">
							<div className="col-md-6 col-lg-3 col-sm-6 col-12 col-xs-12">
								<div className="footer_logo">
									<img src="assets/images/wolf-site-logo.png" className="img-responsive" alt="footer logo"/>
									<p>
										Wolf Watersports offers the best in wakeboarding, wakesurfing, and watersports with MasterCraft Boat Company, as well as, performance and reliability with Ilmor Marine. Give us a call to schedule a demo today!
									</p>
								</div>
							</div>
							<div className="col-md-6 col-lg-3 col-sm-6  col-xs-6">
								<div className="footer_wrapper">
									<h3 className="title">Quick Links</h3>
									<ul>
										<li><a href="#">New Boats</a></li>
										<li><a href="#">Pre-Owned Boats</a></li>
										<li><a href="#">Service & Parts</a></li>
										<li><a href="#">Surf Shop</a></li>
										<li><a href="#">About Us</a></li>
										<li><a href="#">Sell Your Boat/value Your Boat</a></li>
										<li><a href="#">Loan Calculator</a></li>
										<li><a href="#">News & Events</a></li>
										<li><a href="#">Contact Us</a></li>
									
									</ul>
								</div>
							</div>
							<div className="col-md-6 col-lg-4 col-sm-6  col-xs-6">
								<div className="footer_wrapper">
									<h3 className="title">Photo Gallery</h3>
									<ul className="special">
										<li>
											
											<div className="col-lg-6 col-md-6 col-xs-6">
												<div className="from-instagram">
													<img src="assets/images/footer-imgs.png" className="img-responsive"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-6">
												<div className="from-instagram">
													<img src="assets/images/footer-imgs1.png" className="img-responsive"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-6">
												<div className="from-instagram">
													<img src="assets/images/footer-imgs2.png" className="img-responsive"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-6">
												<div className="from-instagram">
													<img src="assets/images/footer-imgs3.png" className="img-responsive"/>
												</div>
											</div>
										
										</li>
										
										<li><a href="#" className="insta-btn"><i className="fa fa-instagram"></i> View More on Instagram</a></li>
									</ul>
								</div>
							</div>
							
							<div className="col-md-6 col-lg-2 col-sm-6  col-xs-6">
								<div className="footer_wrapper">
									<h3 className="title">Contact</h3>
									<ul>
										<div className="contact-info">
											<h3>Mesa:</h3>
											<p>8640 E. Main St</p>
											<p>Mesa, AZ 85207</p>
											<p>1.480.986.8898</p>
										</div>
										<div className="contact-info">
											<h3>LAKE HAVASU:</h3>
											<p>1595 Dover Ave Unit D </p>
											<p> Lake Havasu City, AZ 86404</p>
											<p>1.928.733.7034</p>
										</div>
										<div className="contact-info" style={{"border-bottom": "none"}}>
											<h3>HOURS:</h3>
											<p>Mon – Fri: 9AM – 6PM</p>
											<p>Sat: 10AM – 4PM</p>
											<p>Sun: Closed</p>
										</div>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div className="section-strt blk-footer">
						<div className="text-center">
							<p>  &copy; <a href="#">Wolf WaterSports of Arizona</a> | All Rights Reserved</p>
						</div>
					</div>
				</footer>
			</React.Fragment>
		);
	}
}

export default PageFooter;
