/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from "react";

class SingleNews extends React.Component {
	render() {
		let longArticle = (text)=>{
			return(
				<React.Fragment>
					{text.substr(0,150)}
					<a href={'/event_detail?id='+this.props._id}>READ MORE</a>
				</React.Fragment>
			)
		}
		return (
			<React.Fragment>
				<div className="col-lg-4 col-md-6 col-sm-6 col-12">
					<div className="wrapper">
						<div className="image_frame1">
							<a href={'/event_detail?id='+this.props._id}>
								<h2 className="article-title">
									{this.props.title}
								</h2>
							</a>
							<p className="read-more-this">
								{this.props.text.length>150 ? longArticle(this.props.text) :this.props.text}
							</p>
							<p className="art-date">
								<a className="" href={'/event_detail?id='+this.props._id}><strong className="min">{this.props.date}</strong> <strong className="date">{this.props.month.substr(0,3)}</strong> </a>
							</p>
						</div>
					
					</div>
				</div>
			</React.Fragment>
		);
	}
}

export default SingleNews;
