/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
const baseDomain = "http://www.localhost:3006/public/";
const adminApiDomain = "http://www.localhost:3006/admin/";
const adminLoginURL = "http://www.localhost:3006/auth/admin/login";
const sessionExpireStatus = 440;

export {
	baseDomain,
	adminApiDomain,
	adminLoginURL,
	sessionExpireStatus
}
