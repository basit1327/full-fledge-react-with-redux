import React from 'react';
import './style.css';
import ChangeTitle from '../../components/change_page_title';

const NotFoundIllus = () => <div className="cap-error-page">
	<div id="notfound">
		<div className="notfound">
			<div className="notfound-404">
				<h1>Oops!</h1>
				<h2>404 - The Page can't be found</h2>
			</div>
			<a href={'/admin'}>Go TO Homepage</a>
		</div>
	</div>
</div>;


class NotFound extends React.Component {
	render () {
		return (
			<React.Fragment>
				<div className="content p-0">
					<ChangeTitle title={'404'}/>
					<NotFoundIllus/>
				</div>
			</React.Fragment>
		);
	}
}

export default NotFound;
