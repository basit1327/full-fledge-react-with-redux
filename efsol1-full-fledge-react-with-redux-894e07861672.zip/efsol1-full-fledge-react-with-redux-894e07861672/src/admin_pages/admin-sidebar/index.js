/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from "react";
import $ from 'jquery';
import './style.css';
import { connect } from 'react-redux';
import { updateAdminPage } from '../../redux/actions/adminAction';
import adminPages from '../../utils/admin_pages';
import { adminApiCall } from '../../utils/ajax_request';
import Swal from "sweetalert2";

class AdminSidebar extends React.Component {
	
	componentDidMount () {
		$(".page-link-li").click((event)=>{
			this.handleLinkChange(event)
		})
		
		/* Selecting very first menu item by default */
		$(`#${adminPages[0].childs[0].key}`).addClass('ir_active')
	}
	
	handleLinkChange(event) {
		$(".page-link-li").each(function() {
			$(this).removeClass('ir_active');
		});
		if(event.target.id)
			$(`#${event.target.id}`).addClass('ir_active')
		
		/* Update redux store */
		this.props.updateAdminPage(event.target.id)
	}
	
	renderMenuItems(){
		const _items = [];
		let renderChilds = (childs)=>{
			let _childs = [];
			for ( const [index, element] of childs.entries() ) {
				_childs.push(
					<li id={element.key} className="page-link-li list-group-item"><i className={element.icon} aria-hidden="true"></i> &nbsp;{element.val}</li>
				);
			}
			return _childs
		};
		
		for ( const [index, element] of adminPages.entries() ) {
			console.log('pages',element.category);
			let category = element.category;
			let childs = element.childs;
			_items.push(
				<a datair={'#'+category}>
					<li className="list-group-item"><strong>{category}</strong></li>
					{renderChilds(childs)}
				</a>
			);
		}
		return _items;
	}
	
	async logout(){
		try{
			$('#loader').show();
			let res = await adminApiCall('logout');
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 ) {
					localStorage.clear()
					
					Swal.fire({
						title: 'Logout Successful',
						text: 'Redirecting you to login',
						icon: 'success',
						showConfirmButton: false
					})
					setTimeout(()=>{window.location.href='/admin/login'},2000)
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	render() {
		return (
			<React.Fragment>
				<ul className="list-group menu admin_menu">
					<div className="sidebar_logo"><img src="assets/images/wolf-site-logo.png" alt="" style={{width: "100px"}}/></div>
					{this.renderMenuItems()}
					<a onClick={this.logout.bind(this)}><li className="log_out"><i className="fa fa-sign-out" aria-hidden="true"> </i><span>Log Out</span></li></a>
				</ul>
			</React.Fragment>
		);
	}
}


function MapDispatchToProps() {
	return {
		updateAdminPage
	};
}

export default connect(null,MapDispatchToProps())(AdminSidebar);


