/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import $ from 'jquery';
import { adminApiCall } from '../../../utils/ajax_request';
import Swal from "sweetalert2";
import Pagination from "react-js-pagination";

class ListProduct extends React.Component {
	state = {
		filters:{
			beep:false,
			searchKeyword:'',
		},
		inventoryProducts:[],
		pagination:{
			currentPage:1,
			totalPages:14,
		},
	}
	
	async componentWillMount () {
		this.getProductsData();
	}
	
	async shouldComponentUpdate ( nextProps, nextState, nextContext ) {
		if(this.state.filters !== nextState.filters){
			$('#loader').show();
			setTimeout(()=>{this.getProductsData();},500)
			return true
		}
		else if(this.state.pagination.currentPage !== nextState.pagination.currentPage){
			$('#loader').show();
			setTimeout(()=>{this.getProductsData();},500)
			return true
		}
		else { return false; }
	}
	
	async getProductsData(){
		try{
			$('#loader').show();
			this.setState({inventoryProducts:[]});
			
			let res = await adminApiCall(`get_products?currentPage=${this.state.pagination.currentPage}`,'POST',JSON.stringify(this.state.filters));
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						inventoryProducts : res.data,
						pagination : res.pagination
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	handlePageChange(pageNumber) {
		if(pageNumber){
			let pagination = {...this.state.pagination}
			pagination.currentPage = pageNumber
			this.setState({pagination});
		}
	}
	
	searchByKeyword = ()=>{
		if($('#filter_keyword').val()){
			let filters = {...this.state.filters}
			filters.searchKeyword = $('#filter_keyword').val()
			this.setState({filters});
		}
	}
	
	clearSearchKeyword = ()=>{
		if($('#filter_keyword').val()){
			let filters = {...this.state.filters}
			$('#filter_keyword').val('')
			filters.searchKeyword = ''
			this.setState({filters});
		}
	}
	
	renderProductList(){
		const products = [];
		for ( const [index, element] of this.state.inventoryProducts.entries() ) {
			products.push(
				<li className="list-group-item">
					<h4 className="pull-right" style={{'padding-left': '10px'}}><a className="text-danger" href="/admin/product/delete/5d7b1e39b8271211d0a56404"
						onClick="return confirm('Are you sure you want to delete this product?');"> <i className="fa fa-trash-o"></i></a></h4>
					<h4 className="pull-right"><input id="5d7b1e39b8271211d0a56404" className="published_state" type="checkbox"/></h4>
					<h5><a href="/admin/product/edit/5d7b1e39b8271211d0a56404">{element.productTitle}</a></h5>
				</li>
			);
		}
		return products
	}
	
	render () {
		return (
			<div className="col-lg-12">
					<div className="page-header">
						<h2>Products</h2>
					</div>
					<div className="col-lg-12">
						<div className="input-group">
							<input type="text" name="product_filter" id="filter_keyword" className="form-control input-lg" placeholder="Filter products"/>
							<span className="input-group-btn">
                                <a href="#" onClick={this.searchByKeyword} className="hidden-xs btn-red_cust btn-sm"> <i className="fa fa-filter filter_style" aria-hidden="true"></i></a>
                            	<a href="#" onClick={this.clearSearchKeyword} className="hidden-xs btn-red_cust btn-sm text-danger"><i className="fa fa-times" aria-hidden="true"></i></a>
                        	</span>
						</div>
					</div>
					<div className="col-lg-12">
						<ul className="list-group boat-list">
							{this.renderProductList()}
						</ul>
					</div>
					<div className="pagination-container">
						<Pagination
							activePage={this.state.pagination.currentPage}
							totalItemsCount={this.state.pagination.totalPages}
							pageRangeDisplayed={5}
							activeClass={'active'}
							onChange={this.handlePageChange.bind(this)}
						/>
					</div>
				</div>
		);
	}
}

export default ListProduct
