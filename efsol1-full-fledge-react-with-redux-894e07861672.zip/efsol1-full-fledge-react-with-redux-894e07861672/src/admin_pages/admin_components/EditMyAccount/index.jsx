/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import { Editor } from 'react-draft-wysiwyg';
import { EditorState } from 'draft-js';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';

class EditMyAccount extends React.Component {
	render () {
		return (
			<div className="col-md-12 tab_content">
				<div className="page-header"><h2>User edit</h2>
				</div>
				<div className="col-lg-offset-3 col-lg-6 ">
					<form method="post" id="edit_form" action="/admin/user/update" data-toggle="validator">
						<input type="hidden" name="userId" value="5e054566c7c8f6096c9986f7"/>
						<div className="form-group">
							<label>Users name</label>
							<input type="text" className="form-control" name="usersName" value="Cole" required/>
						</div>
						<div className="form-group">
							<label>User email</label>
							<input type="email" className="form-control" name="userEmail" value="cole@wolfwatersports.com" readOnly/>
						</div>
						<div className="form-group">
							<label>User password </label>
							<input type="password" className="form-control" name="userPassword"/>
						</div>
						<div className="form-group">
							<label>Password confirm </label>
							<input type="password" data-match="#userPassword" data-validation-match-message="Password values to not match" className="form-control"
								name="frm_userPassword_confirm"/>
						</div>
						<div className="checkbox">
							<label>
								<input name="user_admin" type="checkbox"/> User is admin?
							</label>
						</div>
						<div className="form-group">
							<div className="pull-right">
								<button type="submit" className="btn pannel-btn">Update</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		);
	}
}

export default EditMyAccount
