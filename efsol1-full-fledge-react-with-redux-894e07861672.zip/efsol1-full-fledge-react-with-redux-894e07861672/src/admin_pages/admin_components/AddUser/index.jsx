/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';

class AddUser extends React.Component {
	render () {
		return (
			<div className="col-lg-12">
				<div className=" page-header">
					<h2>New User</h2>
				</div>
				<div className="col-lg-offset-3 col-lg-6">
					<form method="post" id="edit_form" action="/admin/user/insert" data-toggle="validator">
						<div className="form-group">
							<label>Users name *</label>
							<input type="text" className="form-control" name="usersName" required/>
						</div>
						<div className="form-group">
							<label>User email *</label>
							<input type="email" className="form-control" name="userEmail" required/>
						</div>
						<div className="form-group">
							<label>User password *</label>
							<input type="password" className="form-control" id="userPassword" name="userPassword" required/>
						</div>
						<div className="form-group">
							<label>Password confirm *</label>
							<input type="password" data-match="#userPassword" className="form-control" name="frm_userPassword_confirm" required/>
						</div>
						<div className="form-group">
							<div className="pull-right">
								<button type="submit" className="btn pannel-btn btn-sm">Create</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		);
	}
}

export default AddUser
