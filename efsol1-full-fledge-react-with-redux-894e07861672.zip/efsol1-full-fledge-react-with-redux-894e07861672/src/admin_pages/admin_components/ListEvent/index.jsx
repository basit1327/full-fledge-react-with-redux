/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import $ from 'jquery';
import { adminApiCall } from '../../../utils/ajax_request';
import Swal from "sweetalert2";
import Pagination from "react-js-pagination";

class ListEvent extends React.Component {
	state = {
		filters:{
			beep:false,
			searchKeyword:'',
		},
		eventsRecords:[],
		pagination:{
			currentPage:1,
			totalPages:14,
		},
	}
	
	async componentWillMount () {
		this.getEventsData();
	}
	
	async shouldComponentUpdate ( nextProps, nextState, nextContext ) {
		if(this.state.filters !== nextState.filters){
			$('#loader').show();
			setTimeout(()=>{this.getEventsData();},500)
			return true
		}
		else if(this.state.pagination.currentPage !== nextState.pagination.currentPage){
			$('#loader').show();
			setTimeout(()=>{this.getEventsData();},500)
			return true
		}
		else { return false; }
	}
	
	async getEventsData(){
		try{
			$('#loader').show();
			this.setState({eventsRecords:[]});
			
			let res = await adminApiCall(`get_events?currentPage=${this.state.pagination.currentPage}`,'POST',JSON.stringify(this.state.filters));
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						eventsRecords : res.data,
						pagination : res.pagination
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	handlePageChange(pageNumber) {
		if(pageNumber){
			let pagination = {...this.state.pagination}
			pagination.currentPage = pageNumber
			this.setState({pagination});
		}
	}
	
	searchByKeyword = ()=>{
		if($('#filter_keyword').val()){
			let filters = {...this.state.filters}
			filters.searchKeyword = $('#filter_keyword').val()
			this.setState({filters});
		}
	}
	
	clearSearchKeyword = ()=>{
		if($('#filter_keyword').val()){
			let filters = {...this.state.filters}
			$('#filter_keyword').val('')
			filters.searchKeyword = ''
			this.setState({filters});
		}
	}
	
	renderEventsList(){
		const events = [];
		for ( const [index, element] of this.state.eventsRecords.entries() ) {
			events.push(
				<li className="list-group-item">
					<h4 className="pull-right pl-10"><a className="text-danger" href="/admin/event/delete/5d8366405a58572b28d8890f"
						onClick="return confirm('Are you sure you want to delete this event?');"> <i className="fa fa-trash-o"></i></a></h4>
					<h5><a href="/admin/event/edit/5d8366405a58572b28d8890f">{element.eventTitle} </a></h5>
				</li>
			);
		}
		return events
	}
	
	render () {
		return (
			<div className="col-lg-12">
				<div className=" page-header">
					<h2>Events</h2>
				</div>
				<div className="col-lg-12">
					<div className="input-group">
						<input type="text" name="event_filter" id="filter_keyword" className="form-control input-lg" placeholder="Filter events"/>
						<span className="input-group-btn">
							<a href="#" onClick={this.searchByKeyword} className="hidden-xs btn-red_cust btn-sm"> <i className="fa fa-filter filter_style" aria-hidden="true"></i></a>
							<a href="#" onClick={this.clearSearchKeyword} className="hidden-xs btn-red_cust btn-sm text-danger"><i className="fa fa-times" aria-hidden="true"></i></a>
						</span>
					</div>
				</div>
				<div className="col-lg-12">
					<ul className="list-group boat-list">
						{this.renderEventsList()}
					</ul>
				</div>
				<div className="pagination-container">
					<Pagination
						activePage={this.state.pagination.currentPage}
						totalItemsCount={this.state.pagination.totalPages}
						pageRangeDisplayed={5}
						activeClass={'active'}
						onChange={this.handlePageChange.bind(this)}
					/>
				</div>
			</div>
		);
	}
}

export default ListEvent
