import React from 'react';

class GeneralSetting extends React.Component {
	render () {
		return (
			<div className="col-lg-12">
				<div className=" page-header">
					<h2 className="clearfix">General Settings
					</h2>
				</div>
				<div className="pull-right">
					<button type="submit" className="updateSettingsAdmin btn pannel-btn btn-sm">Update</button>
				</div>
				<div className="clearfix"></div>
				<div className="form-group">
					<label>Cart name *</label>
					<input type="text" className="form-control" id="cart-title" name="cartTitle" value="Wolf" required/>
					<p className="help-block">This element is critical for search engine optimisation. Cart title is displayed if your logo is hidden.</p>
				</div>
				<div className="form-group">
					<label>Cart description *</label>
					<input type="text" className="form-control" id="cart-description" name="cartDescription" value="Latest boats, Surfing and Accessories" required/>
					<p className="help-block">This description shows when your website is listed in search engine results.</p>
				</div>
				<div className="form-group">
					<label>Cart image/logo</label>
					<input type="text" className="form-control" id="cartLogo" value="/assets/images/wolf-site-logo.png"/>
				</div>
				<div className="form-group">
					<label>Cart URL *</label>
					<input type="text" className="form-control" id="baseUrl" value="https://wolfwatersports.com/" required/>
						<p className="help-block">This URL is used in sitemaps and when your customer returns from completing their payment.</p>
				</div>
				<div className="form-group">
					<label>Cart Email *</label>
					<input type="email" className="form-control" id="emailAddress" value="hi@markmoffat.com" required/>
						<p className="help-block">This is used as the "from" email when sending receipts to your customers.</p>
				</div>
				<div className="form-group">
					<label>Flat shipping rate *</label>
					<input type="text" className="form-control" id="flatShipping" value="10" required/>
						<p className="help-block">A flat shipping rate applied to all orders.</p>
				</div>
				<div className="form-group">
					<label>Free shipping threshold</label>
					<input type="text" className="form-control" id="freeShippingAmount" value="100"/>
					<p className="help-block">Orders over this value will mean the shipped will the FREE. Set to high value if you always want to charge shipping.</p>
				</div>
				<div className="form-group">
					<label>Payment gateway</label>
					<select className="form-control" id="paymentGateway">
						<option value="paypal">Paypal</option>
						<option value="stripe">Stripe</option>
						<option selected value="authorizenet">Authorize</option>
					</select>
					<p className="help-block">You will also need to configure your payment gateway credentials in the `/config/&lt;gateway_name&gt;.json` file.</p>
				</div>
				<div className="form-group">
					<label>Currency symbol</label>
					<input type="text" className="form-control" id="currencySymbol" value="$"/>
					<p className="help-block">Set this to your currency symbol. Eg: $, £, €</p>
				</div>
				<div className="form-group">
					<label>Theme</label>
					<select className="form-control" id="theme">
						<option selected value="Material">Material</option>
					</select>
					<p className="help-block">Themes are loaded from `/public/themes/`</p>
				</div>
				<div className="form-group">
					<label>Products per row</label>
					<select className="form-control" id="productsPerRow">
						<option value="3" hidden="hidden" selected="selected">3</option>
						<option>1</option>
						<option>2</option>
						<option>3</option>
						<option>4</option>
					</select>
					<p className="help-block">The number of products to be displayed across the page.</p>
				</div>
				<div className="form-group">
					<label>Products per page</label>
					<input type="number" className="form-control" id="productsPerPage" value="24"/>
					<p className="help-block">The number of products to be displayed on each page.</p>
				</div>
				<div className="form-group">
					<label>Menu Enabled: </label>
					<div className="checkbox">
						<label>
							<input className="settingsMenuEnabled" type="checkbox" id="menuEnabled" id="menuEnabled"/>
						</label>
					</div>
					<p className="help-block">If a menu is set you can set it up
						<a href="/admin/settings/menu">here</a>.</p>
				</div>
				<div className="form-group">
					<label>Menu header</label>
					<input type="text" className="form-control" id="menuTitle" value="Menu" placeholder="Menu"/>
					<p className="help-block">The heading text for your menu.</p>
				</div>
				<div className="form-group">
					<label>Menu location: </label>
					<select className="form-control" id="menuLocation">
						<option>top</option>
						<option selected>side</option>
					</select>
					<p className="help-block">The location of your menu.</p>
				</div>
				<div className="form-group">
					<label>Footer HTML</label>
					<textarea className="form-control codemirrorArea" rows="5" id="footerHtml" name="footerHtml"></textarea>
					<input type="hidden" id="footerHtml_input"/>
				</div>
				<div className="form-group">
					<label>Google Tag Manager Header</label>
					<textarea className="form-control" rows="3" id="googleTagManagerHeader"
						name="googleTagManagerHeader"></textarea>
						<input type="hidden" id="googleTagManagerHeader_input" name="googleTagManagerHeader_input" />
						<p class="help-block">Your Google Header Tag Manger code. Please also inlude the "script" tags -
						<a href="https://support.google.com/analytics/answer/1032385?hl=en"
						target="_blank">Help</a>
						</p>
						</div>
				<div class="form-group">
						<label>Google Tag Manager Body</label>
						<textarea class="form-control" rows="3" id="googleTagManagerBody" name="googleTagManagerBody">&lt;noscript&gt;&lt;iframe src&#x3D;&quot;https://www.googletagmanager.com/ns.html?id&#x3D;GTM-NTSGS8J&quot;
						height&#x3D;&quot;0&quot; width&#x3D;&quot;0&quot; style&#x3D;&quot;display:none;visibility:hidden&quot;&gt;&lt;/iframe&gt;&lt;/noscript&gt;</textarea>
						<input type="hidden" id="googleTagManagerBody_input" name="googleTagManagerBody_input" value=""/>
						<p class="help-block">Your Google Body Analytics code. Please also inlude the "script" tags -
							<a href="https://support.google.com/analytics/answer/1032385?hl=en" target="_blank">Help</a>
						</p>
						</div>
				<div class="form-group">
						<label>Google analytics</label>
						<textarea class="form-control" rows="3" id="googleAnalytics" name="googleAnalytics"></textarea>
						<input type="hidden" id="googleAnalytics_input" name="googleAnalytics_input" value=""/>
						<p class="help-block">Your Google Analytics code. Please also inlude the "script" tags -
						<a href="https://support.google.com/analytics/answer/1032385?hl=en"
						target="_blank">Help</a>
						</p>
						</div>
				<div class="form-group">
						<label>Custom CSS</label>
						<textarea class="form-control" rows="10" id="customCss" name="customCss"></textarea>
						<input type="hidden" id="customCss_input" name="customCss_input"/>
						</div>
				<h3 className="clearfix text-center ">Email Settings</h3>
					<div className="form-group">
						<label>Email SMTP Host</label>
						<input type="text" className="form-control" id="emailHost" value="smtp-mail.outlook.com" autoComplete="off" required/>
					</div>
					<div className="form-group">
						<label>Email SMTP Port</label>
						<input type="text" className="form-control" id="emailPort" value="587" autoComplete="off" required/>
					</div>
					<div className="form-group">
						<label>Email SMTP secure </label>
						<div className="checkbox">
							<label>
								<input className="settingsMenuEnabled" type="checkbox" id="emailSecure"/>
							</label>
						</div>
					</div>
					<div className="form-group">
						<label>Sendgrid API Key</label>
						<input type="text" className="form-control" name="apiKeySendGrid" id="apiKeySendGrid" value="" autoComplete="off"/>
					</div>
					<h3 className="clearfix text-center ">Google recaptcha Settings</h3>
					<div className="form-group">
						<label>Recaptcha Private key</label>
						<input type="text" className="form-control" name="recaptchaPrivateKey" id="recaptchaPrivateKey" value="6LcvDZcUAAAAAGYHmLfwm8Y2Bv0xperx2jAubkqg" autoComplete="off"/>
					</div>
				<h3 className="clearfix text-center ">Newsletter Settings</h3>
				<div className="form-group">
								<label>Enable Newsletter </label>
								<div className="checkbox">
									<label>
										<input className="settingsMenuEnabled" type="checkbox" id="newsletterActive"/>
									</label>
								</div>
							</div>
				<div className="form-group">
								<label>MailChimp API Key</label>
								<input type="text" className="form-control" id="mailChimpApiKey" value="35e0ea6d756b875d5f3d9c07a0a8a560-us19" autoComplete="off"/>
							</div>
				<div className="form-group">
								<label>MailChimp List Id</label>
								<input type="text" className="form-control" id="mailChimpListId" value="94c0f63ce8" autoComplete="off"/>
							</div>
				<div className="form-group">
								<button className="updateSettingsAdmin btn pannel-btn pull-right btn-sm">Update Changes</button>
							</div>
			</div>
		);
	}
}

export default GeneralSetting
