/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import { EditorState, ContentState, convertFromHTML,convertToRaw } from 'draft-js';
import { Editor } from 'react-draft-wysiwyg';
import draftToHtml from 'draftjs-to-html';
import $ from 'jquery';
import { adminApiCall } from '../../../utils/ajax_request';
import Swal from "sweetalert2";

class EmailNotification extends React.Component {
	
	initialTemplateData = {
		template_slug:'',
		template_name:'',
		email_to:'',
		bcc:'',
		from:'',
		from_email:'',
		email_subject:'',
		content:''
	}
	
	state = {
		editorState:EditorState.createEmpty(),
		editorPlainHtml:'',
		emailTemplatesRecord:[],
		templateData:this.initialTemplateData
	};
	
	async componentWillMount() {
		this.getTemplateList();
	}
	
	async getTemplateList(){
		try{
			$('#loader').show();
			let res = await adminApiCall(`get_email_templates`,'GET');
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						emailTemplatesRecord : res.data
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	async templateChange(){
		if($('#email-template').val()){
			try{
				$('#loader').show();
				let res = await adminApiCall(`get_email_template_data?slug=${$('#email-template').val()}`,'GET');
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 && res.hasOwnProperty('data') ) {
						this.setState({
							templateData : res.data,
							editorState: EditorState.createWithContent(
								ContentState.createFromBlockArray(
									convertFromHTML(res.data.content)
								)
							)
						});
						/*hitting editor state change event*/
						this.onEditorStateChange(this.state.editorState)
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
			catch ( e ){
				Swal.fire({
					title: 'Error!',
					text: 'Something gone wrong...',
					icon: 'error',
				})
				console.log(e);
			}
			finally {
				$('#loader').hide();
			}
		}
		else {
			this.setState({
				templateData : this.initialTemplateData,
				editorState: EditorState.createWithContent(
					ContentState.createFromBlockArray(
						convertFromHTML('')
					)
				)
			});
		}
	}
	
	async updateTemplate(){
		if($('#email-template').val() && this.state.templateData !== {}){
			try{
				$('#loader').show();
				let data = this.state.templateData
				data.content = this.state.editorPlainHtml
				let res = await adminApiCall(`update_email_template_data`,'POST',JSON.stringify(data));
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 ) {
						Swal.fire({
							title: 'Success',
							text: res.message,
							icon: 'success',
						})
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
			catch ( e ){
				Swal.fire({
					title: 'Error!',
					text: 'Something gone wrong...',
					icon: 'error',
				})
				console.log(e);
			}
			finally {
				$('#loader').hide();
			}
		}
	}
	
	renderTemplateList(){
		const templates = [];
		for ( const [index, element] of this.state.emailTemplatesRecord.entries() ) {
			templates.push(
				<option value={element.template_slug}>{element.template_name}</option>
			);
		}
		
		return (
			<select id="email-template" onChange={this.templateChange.bind(this)} name="email_template" className="form-control">
				<option value={''}>--select template--</option>
				{templates}
			</select>
		)
	}
	
	onEditorStateChange = (editorState)=>{
		let editorSourceHTML = draftToHtml(convertToRaw(editorState.getCurrentContent()))
		this.setState({
			editorState,
			editorPlainHtml:editorSourceHTML
		});
	}
	
	render () {
		return (
			<div className="col-lg-12">
				<div className="page-header"><h2 className="email_heading">Email Notifications</h2></div>
				<div>
					<input value="" type="hidden" id="data_ID" name="email_Id"/>
						<div className="clearfix"></div>
						<div className="panel-group">
							<div className="panel panel-primary">
								<div className="panel panel-heading">
									Email Template
								</div>
								<div className="panel panel-body">
									<div className="col-xs-12">
										<div className="row">
											<div className="col-xs-12 col-md-6">
												<div className="col-xs-12 form-group">
													<label>Template Name</label>
													{this.renderTemplateList()}
												</div>
												<div className="col-xs-12 form-group">
													<label>Email To</label>
													<input className="input_field form-control" type="text" value={this.state.templateData.email_to} name="email_to"/>
												</div>
											</div>
											<div className="col-xs-12 col-md-6">
												<div className="col-xs-12 form-group">
													<label>BCC</label>
													<input className="input_field form-control" type="text" value={this.state.templateData.bcc}/>
												</div>
												<div className="col-xs-12 form-group">
													<label>From</label>
													<input className="input_field form-control" type="text" value={this.state.templateData.from}/>
												</div>
												<div className="col-xs-12 form-group">
													<label>From Email</label>
													<input className="input_field form-control" type="text" value={this.state.templateData.from_email}/>
												</div>
												<div className="col-xs-12 form-group">
													<label>Email Subject</label>
													<input className="input_field form-control" type="text" value={this.state.templateData.email_subject}/>
												</div>
											</div>
											<div className="col-xs-12">
												<div className="col-xs-12 form-group ck_own_edit">
													<label>Email Text</label>
													<Editor
														name={'content'}
														editorState={this.state.editorState}
														toolbarClassName="toolbarClassName"
														wrapperClassName="wrapperClassName"
														editorClassName="editorClassName"
														onEditorStateChange={this.onEditorStateChange}
													/>
												</div>
												<div className="col-xs-12 form-group">
													<button type="submit" className="btn pannel-btn pull-right" onClick={this.updateTemplate.bind(this)}>Save Changes</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className="clearfix"></div>
				</div>
			</div>
		);
	}
}

export default EmailNotification
