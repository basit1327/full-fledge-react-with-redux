/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import $ from 'jquery';
import { adminApiCall } from '../../../utils/ajax_request';
import Swal from "sweetalert2";

class EmailTemplateSetting extends React.Component {
	
	state = {
		emailTemplatesRecord:[]
	}
	
	async componentWillMount () {
		this.getEmailTemplates();
	}
	
	async getEmailTemplates(){
		try{
			$('#loader').show();
			let res = await adminApiCall(`get_email_templates`,'GET');
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						emailTemplatesRecord : res.data
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	async createNewTemplate(){
		try{
			if($('#slug').val() && $('#name').val()){
				$('#loader').show();
				let res = await adminApiCall(`create_email_template`,'POST',JSON.stringify({slug:$('#slug').val(), name: $('#name').val()}));
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 && res.hasOwnProperty('data') ) {
						Swal.fire({
							title: 'Succeed',
							text: res.message,
							icon: 'success',
						})
						this.setState({
							emailTemplatesRecord : this.state.emailTemplatesRecord.concat(res.data)
						});
						$('#slug').val('')
						$('#name').val('')
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	deleteTemplate = async (event)=>{
		try{
			if(event.target.id){
				$('#loader').show();
				let res = await adminApiCall(`delete_email_template?id=${event.target.id}`,'GET');
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 ) {
						Swal.fire({
							title: 'Succeed',
							text: res.message,
							icon: 'success',
						})
						let removingIndex = this.state.emailTemplatesRecord.map(e=>e._id==event.target.id).indexOf(true)
						this.state.emailTemplatesRecord.splice(removingIndex,1)
						this.setState({
							emailTemplatesRecord : this.state.emailTemplatesRecord
						});
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	renderTemplateList(){
		const templates = [];
		for ( const [index, element] of this.state.emailTemplatesRecord.entries() ) {
			templates.push(
				<tr>
					<td>{element.template_slug}</td>
					<td>{element.template_name}</td>
					<td>
						<a className="text-danger pull-right" href="#" onClick={this.deleteTemplate}>
							<i id={element._id} className="fa fa-trash-o"></i>
						</a>
					</td>
				</tr>
			);
		}
		return templates
	}
	
	render () {
		return (
			<div className="col-lg-12">
				<div className="page-header">
					<h2 className="email_heading">Template Setting</h2>
				</div>
				<div className="clearfix"></div>
				<div className="panel-group">
					<div className="panel panel-primary">
						<div className="panel panel-heading">
							Template Settings
						</div>
						<div className="panel panel-body">
							<div className="col-xs-12">
								<div className="row">
									<div className="col-lg-6 col-md-6">
										<div className="col-xs-12 form-group">
											<label>Template Slug</label>
											<input className="input_field form-control" type="text" id={'slug'}/>
										</div>
									</div>
									<div className="col-lg-6 col-md-6">
										<div className="col-xs-12 form-group">
											<label>Template Name</label>
											<input className="input_field form-control" type="text" id={'name'}/>
										</div>
									</div>
									<div className="col-lg-12 col-md-6">
										<div className="col-lg-12 form-group">
											<button onClick={this.createNewTemplate.bind(this)} className="save_btn pull-right pannel-btn btn">Save Changes</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<div className="clearfix"></div>
				<div className="panel-group">
					<div className="panel panel-primary">
						<div className="panel panel-heading">
							Template List
						</div>
						<div className="panel panel-body">
							<div className="col-xs-12">
								<div className="row">
									<div className="col-xs-12">
										<table className="table table-hover">
											<thead>
											<tr>
												<th>Template Slug</th>
												<th>Template Name</th>
												<th className="text-right">Delete</th>
											</tr>
											</thead>
											<tbody>
												{this.renderTemplateList()}
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="clearfix"></div>
			
			</div>
		);
	}
}

export default EmailTemplateSetting
