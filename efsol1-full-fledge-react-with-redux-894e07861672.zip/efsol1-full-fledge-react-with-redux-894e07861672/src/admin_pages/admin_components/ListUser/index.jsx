/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import $ from 'jquery';
import { adminApiCall } from '../../../utils/ajax_request';
import Swal from "sweetalert2";

class ListUser extends React.Component {
	state = {
		usersRecords:[]
	}
	
	async componentWillMount () {
		this.getUsers();
	}
	
	async getUsers(){
		try{
			$('#loader').show();
			let res = await adminApiCall(`get_users`,'GET');
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						usersRecords : res.data
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	renderUsersList(){
		const users = [];
		for ( const [index, element] of this.state.usersRecords.entries() ) {
			users.push(
				<li className="list-group-item">
					<strong>User:</strong> {element.userName} - ({element.userEmail})
					<span className="pull-right">
						<strong>Role: </strong>
						<span>{element.isAdmin?'Admin':'User'}</span>
					</span>
				</li>
			);
		}
		return users
	}
	
	render () {
		return (
			<div className="col-lg-12">
				<div className="page-header">
					<h2>Users </h2>
				</div>
				<div className="col-lg-offset-3 col-lg-6">
					<div className="clearfix"></div>
					<ul className="list-group">
						{this.renderUsersList()}
					</ul>
				</div>
			</div>
		);
	}
}

export default ListUser
