/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import $ from 'jquery';
import { adminApiCall } from '../../../utils/ajax_request';
import Swal from "sweetalert2";

class EmailSetting extends React.Component {
	state = {
		sandbox_switch : 'off',
		sandbox_email : ''
	}
	
	async componentWillMount () {
		this.getEmailSetting();
	}
	
	async getEmailSetting(){
		try{
			$('#loader').show();
			let res = await adminApiCall(`get_email_setting`,'GET');
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						sandbox_switch: res.data.sandbox_switch,
						sandbox_email: res.data.sandbox_email
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	async saveEmailSetting(){
		try{
			$('#loader').show();
			let res = await adminApiCall(`save_email_setting`,'POST',JSON.stringify({setting:this.state}));
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 ) {
					Swal.fire({
						title: 'Succeed',
						text: res.message,
						icon: 'success',
					})
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	sandboxEmailChangeHandler(event) {
		this.setState({sandbox_email: event.target.value});
	}
	
	sandboxSwitchChangeHandler() {
		this.setState({sandbox_switch: $("#sandbox-switch").is(':checked')?'on':'off'});
	}
	
	render () {
		return (
			<div className="col-lg-12">
				<div className="page-header">
					<h2 className="email_heading">Email Setting</h2>
				</div>
				<div className="clearfix"></div>
				
				<div className="panel-group">
					<div className="panel panel-primary">
						<div className="panel panel-heading">
							Sandbox Setting
						</div>
						<div className="panel panel-body">
							<div className="email_short_boxx">
								<div className="row">
									<div className="col-xs-12 col-sm-12 col-md-6 email_panel">
										<div className="row">
											<div className="col-md-4">
												<div className="email_label">
													<label className="pr-10">Sandbox</label>
													<input id={'sandbox-switch'} onChange={this.sandboxSwitchChangeHandler.bind(this)}
														checked={this.state.sandbox_switch == 'on' ? true : false} className="checkbox mr-10" type="checkbox"/>
												</div>
											</div>
										</div>
									</div>
									
									<div className="col-xs-12 col-sm-12 col-md-6 email_panel">
										<div className="row">
											<div className="col-md-4">
												<div className="email_label">
													<label>Sandbox Email</label>
												</div>
											</div>
											<div className="col-md-10"><input className="form-control" type="text" name="sandbox_email" value={this.state.sandbox_email}
												onChange={this.sandboxEmailChangeHandler.bind(this)}/></div>
										</div>
									
									</div>
									<div className="clearfix"></div>
									<div className="col-lg-12 save_changes_box ">
										<button className="save_btn btn pannel-btn pull-right" onClick={this.saveEmailSetting.bind(this)}>Save Changes</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<div className="clearfix"></div>
			
			</div>
		);
	}
}

export default EmailSetting
