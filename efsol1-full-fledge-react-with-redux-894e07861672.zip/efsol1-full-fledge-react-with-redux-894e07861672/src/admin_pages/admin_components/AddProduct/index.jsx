/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import { Editor } from 'react-draft-wysiwyg';
import { EditorState } from 'draft-js';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';

class AddProduct extends React.Component {
	
	state = {
		editorState:null,
	};
	
	constructor(props) {
		super(props);
		this.state = {
			editorState: EditorState.createEmpty(),
		};
	}
	
	onEditorStateChange = (editorState)=>{
		this.setState({
			editorState,
		});
	}
	
	render () {
		return (
			<div className="col-lg-12">
				<div className="page-header">
					<div className="file-field">
						<h2 className="PRO_SHOP_title">New product</h2>
					</div>
				</div>
				<form method="post" className="form-horizontal" id="insert_form" action="/admin/product/insert" data-toggle="validator">
					<div className="form-group">
						<label htmlFor="frmProductTitle" className="col-sm-2 control-label">Product title *</label>
						<div className="col-sm-10">
							<input type="text" id="frmProductTitle" name="frmProductTitle" className="form-control" minLength="5" maxLength="200" value="" required/>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="frmProductPrice" className="col-sm-2 control-label">Product price *</label>
						<div className="col-sm-6">
							<div className="input-group">
								<span className="input-group-addon">$</span>
								<input type="number" name="frmProductPrice" className="form-control" step="any" value="" required/>
							</div>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="frmProductPrice" className="col-sm-2 control-label">Regular price *</label>
						<div className="col-sm-6">
							<div className="input-group">
								<span className="input-group-addon">$</span>
								<input type="number" name="frmRegularPrice" className="form-control" step="any" value="" required/>
							</div>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="frmProductPublished" className="col-sm-2 control-label">Status</label>
						<div className="col-sm-6 caret_do_cust">
							<select className="form-control select_form_admin" id="frmProductPublished" name="frmProductPublished">
								<option value="true" selected>Published</option>
								<option value="false">Draft</option>
							</select>
						</div>
					</div>
					<div className="form-group" id="editor-wrapper">
						<label htmlFor="editor" className="col-sm-2 control-label">Product description *</label>
						<div className="col-sm-10">
							<Editor
								editorState={this.state.editorState}
								toolbarClassName="toolbarClassName"
								wrapperClassName="wrapperClassName"
								editorClassName="editorClassName"
								onEditorStateChange={this.onEditorStateChange}
							/>
						</div>
					
					</div>
					<div className="form-group">
						<label className="col-sm-2 control-label">Permalink</label>
						<div className="col-sm-10">
							<div className="input-group">
								<input type="text" className="form-control" name="frmProductPermalink" id="frmProductPermalink"
									placeholder="Permalink for the article" value=""/>
								<span className="input-group-btn">
                                            	<a href="/admin/products" className="hidden-xs btn-red_cust btn-sm"> <i style={{"font-size": "25px",color: "#5a5c5d"}} aria-hidden="true" className="fa fa-check "></i></a>
                                    		</span>
							</div>
							<p className="help-block">This sets a readable URL for the product</p>
						</div>
					</div>
					
					<div className="col-sm-8">
						<div className="form-group">
							<label htmlFor="productBrand" className="col-sm-3 control-label">Product Brand</label>
							<div className="col-sm-9 caret_do_cust">
								<select className="form-control select_form_admin" id="productBrand" name="productBrand">
									<option value="" selected>Select</option>
									<option value="cwb">CWB</option>
									<option value="oneil">O'NEIL</option>
									<option value="hyperlite">Hyperlite</option>
									<option value="liquid_force">Liquid Force</option>
									<option value="ride">Ride</option>
									<option value="wake_roots">Wakeroots</option>
									<option value="ronix">Ronix</option>
									<option value="bern">Bern</option>
								</select>
							</div>
						</div>
						
						<div className="form-group">
							<label htmlFor="product_year" className="col-sm-3 control-label">Product Year</label>
							<div className="col-sm-9">
								<input type="text" className="form-control" id="product_year" name="product_year"/>
							</div>
						</div>
						
						<div className="form-group">
							<label htmlFor="product_length_feet" className="col-sm-3 control-label">Product Length</label>
							<div className="col-sm-4">
								<input type="number" className="form-control populate_length" id="product_length_feet" name="product_length_feet" placeholder="feet (ex: 12)"/>
							</div>
							<label className="col-sm-1 text-center">-</label>
							<div className="col-sm-4">
								<input type="number" className="form-control populate_length" id="product_length_inch" name="product_length_inch" placeholder="Inches (ex: 6)"/>
							</div>
						
						</div>
						<div className="form-group">
							<label className="col-sm-3 text-center"></label>
							<div className="col-sm-9">
								<input readOnly type="text" className="form-control" id="product_length" name="product_length" placeholder="0 FT 0 IN" value="0 FT 0 IN"/>
							</div>
						</div>
					
					</div>
					
					<div className="col-sm-4 margin_bott_cus">
						<label>Categories</label>
						<div className="col-sm-12" id="categories">
						</div>
					</div>
					<div id="data-list"></div>
					
					<div className="form-group">
						<label htmlFor="field_name" className="col-sm-2 control-label">Product Data</label>
						<div className="col-sm-3 caret_do_cust">
							<select id="field_name" className="form-control select_form_admin">
								<option value="overview">Overview</option>
								<option value="specs">Specs</option>
								<option value="video_url">Video URL</option>
								<option value="expert_reviews">Expert Reviews</option>
								<option value="customer_reviews">Customer Reviews</option>
							</select>
						</div>
						
						<label htmlFor="field_data_description" className="col-sm-2 control-label">Description</label>
						<div className="col-sm-3">
							<input type="text" className="form-control" id="field_data_description" name="field_data_description" required/>
						</div>
						
						<div className="col-sm-1">
							<button className="btn pannel-btn btn-sm btn-block" type="button" onClick="add_data_field()">Add</button>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="frmProductTags" className="col-sm-2 control-label">Product tag words</label>
						<div className="col-sm-10">
							<input type="text" className="form-control" id="frmProductTags" name="frmProductTags"/>
							<p className="help-block">Tag words used to indexed products, making them easier to find and filter.</p>
						</div>
					</div>
				</form>
			</div>
		);
	}
}

export default AddProduct
