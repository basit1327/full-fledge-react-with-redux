/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import { Editor } from 'react-draft-wysiwyg';
import { EditorState } from 'draft-js';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';

class AddEvent extends React.Component {
	state = {
		editorState:null,
	};
	
	constructor(props) {
		super(props);
		this.state = {
			editorState: EditorState.createEmpty(),
		};
	}
	
	onEditorStateChange = (editorState)=>{
		this.setState({
			editorState,
		});
	}
	
	render () {
		return (
			<div class="col-lg-12">
				<div class="page-header">
					<h2>New Event</h2>
				
				
				</div>
				<div class="upload_file_area">
					<label class="btn pannel-btn btn-sm float-left">
						<i class="fa fa-upload" aria-hidden="true"></i>Upload File
						<input type="file" name="productImage"/>
					</label>
					<div class="pull-right">
						<button id="frm_edit_boat_save" class="btn pannel-btn btn-sm btn-block" type="submit">Add Event <i class="fa fa-plus"></i></button>
					</div>
					<div class="clearfix"></div>
				</div>
				<form method="post" class="form-horizontal" id="insert_form" action="/admin/event/insert" data-toggle="validator" enctype="multipart/form-data" >
					<div class="form-group">
						<label for="eventTitle" class="col-sm-2 control-label">Title *</label>
						<div class="col-sm-10">
							<input type="text" name="eventTitle" class="form-control" minlength="5" maxlength="200" value="" required/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Permalink</label>
						<div class="col-sm-9">
							<input type="text" readonly class="form-control" name="eventPermalink" id="eventPermalink" placeholder="Permalink for the article"/>
							<p class="help-block">This sets a readable URL for the Event</p>
						</div>
						<div class="col-sm-1">
                            <span class="input-group-btn"></span>
						</div>
					</div>
					<div class="form-group">
						<label for="pageContent" class="col-sm-2 control-label">Description *</label>
						<div class="col-sm-10">
							<Editor
								id={'pageContent'}
								name={'eventDescription'}
								editorState={this.state.editorState}
								toolbarClassName="toolbarClassName"
								wrapperClassName="wrapperClassName"
								editorClassName="editorClassName"
								onEditorStateChange={this.onEditorStateChange}
							/>
						</div>
					</div>
					<div class="form-group">
						<label for="event_year" class="col-sm-2 control-label">Event Year</label>
						<div class="col-sm-10">
							<select class="form-control" required name="eventYear">
								<option>Select</option>
								<option  value="2019">2019</option>
								<option  value="2020">2020</option>
								<option  value="2021">2021</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="event_year" class="col-sm-2 control-label">Event Month</label>
						<div class="col-sm-10">
							<select class="form-control" required name="eventMonth">
								<option>Select</option>
								<option    value='Janaury'>Janaury</option>
								<option   value='February'>February</option>
								<option   value='March'>March</option>
								<option   value='April'>April</option>
								<option   value='May'>May</option>
								<option   value='June'>June</option>
								<option   value='July'>July</option>
								<option   value='August'>August</option>
								<option   value='September'>September</option>
								<option   value='October'>October</option>
								<option   value='November'>November</option>
								<option   value='December'>December</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="address" class="col-sm-2 control-label">Event Location</label>
						<div class="col-sm-3">
							<input type="text" class="form-control" id="location-name" placeholder="Location name *" name="location_name" required />
						</div>
						<div class="col-sm-7">
							<input type="text" class="form-control" id="address" placeholder="Street address *" name="address" required/>
						</div>
					</div>
					<div class="form-group">
						<label for="event_city" class="col-sm-2 control-label"></label>
						<div class="col-sm-3">
							<input type="text" class="form-control" id="city" placeholder="City *" name="city" required/>
						</div>
						
						<div class="col-sm-3">
							<input type="text" class="form-control" id="zipcode" name="zipcode" placeholder="zipcode"/>
						</div>
						
						<div class="col-sm-4">
							<input type="text" class="form-control" id="state" name="state" placeholder="State"/>
						</div>
					
					</div>
					<div class="form-group">
						<label for="event_city" class="col-sm-2 control-label"></label>
						<div class="col-sm-3">
							<input type="text" class="form-control" id="country" name="country" placeholder="Country"/>
						</div>
					</div>
				</form>
			</div>
		);
	}
}

export default AddEvent
