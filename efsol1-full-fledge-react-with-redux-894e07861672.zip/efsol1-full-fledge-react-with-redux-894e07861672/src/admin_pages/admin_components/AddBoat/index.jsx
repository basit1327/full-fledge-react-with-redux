/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import { Editor } from 'react-draft-wysiwyg';
import { EditorState } from 'draft-js';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';

class AddBoat extends React.Component {
	state = {
		editorState:null,
	};
	
	constructor(props) {
		super(props);
		this.state = {
			editorState: EditorState.createEmpty(),
		};
	}
	
	onEditorStateChange = (editorState)=>{
		this.setState({
			editorState,
		});
	}
	
	render () {
		return (
			<div className="col-lg-12">
				<div className="page-header">
					<h2>New boat</h2>
				</div>
				<div className="upload_file_area">
					<label className="btn pannel-btn btn-sm float-left">
						<i className="fa fa-upload" aria-hidden="true"></i>Upload File
						<input type="file" name="productImage"/>
					</label>
					<div className="pull-right">
						<button id="frm_edit_boat_save" className="btn pannel-btn btn-sm btn-block" type="submit">Add boat <i className="fa fa-plus"></i></button>
					</div>
					<div className="clearfix"></div>
				</div>
				<form method="post" className="form-horizontal" id="insert_form" action="/admin/boat/insert" data-toggle="validator">
					<div className="form-group">
						<label htmlFor="frmboatTitle" className="col-sm-2 control-label">Title *</label>
						<div className="col-sm-10">
							<input type="text" name="frmboatTitle" className="form-control" minLength="5" maxLength="200" value="" required/>
						</div>
					</div>
					<div className="form-group">
						<label className="col-sm-2 control-label">Permalink</label>
						<div className="col-sm-10">
							<div className="">
								<input type="text" readOnly className="form-control" name="frmboatPermalink" id="frmboatPermalink" placeholder="Permalink for the article"/>
							</div>
							<p className="help-block">This sets a readable URL for the boat</p>
						</div>
					</div>
					<div className="form-group">
						<label htmlFor="pageContent" className="col-sm-2 control-label">Description *</label>
						<div className="col-sm-10">
							<Editor
								id={'pageContent'}
								name={'frmboatDescription'}
								editorState={this.state.editorState}
								toolbarClassName="toolbarClassName"
								wrapperClassName="wrapperClassName"
								editorClassName="editorClassName"
								onEditorStateChange={this.onEditorStateChange}
							/>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="dealer_name" className="col-sm-2 control-label"></label>
						<div className="col-sm-5">
							<input type="text" name="dealer_name" className="form-control" placeholder="Dealer Name" value=""/>
						</div>
						
						<div className="col-sm-5">
							<input type="text" name="telephone" className="form-control" placeholder="Telephone" value=""/>
						</div>
					
					</div>
					
					<div className="form-group">
						<label htmlFor="city" className="col-sm-2 control-label"></label>
						<div className="col-sm-3">
							<input type="text" name="city" placeholder="City" className="form-control" value=""/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" name="state" className="form-control" placeholder="State" value=""/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" name="zip" className="form-control" placeholder="Zip" value=""/>
						</div>
					
					</div>
					
					<div className="form-group">
						<label htmlFor="engine_model" className="col-sm-2 control-label"></label>
						<div className="col-sm-3">
							<input type="text" name="engine_model" className="form-control" placeholder="Engine Model" value=""/>
						</div>
						<div className="col-sm-3">
							<input type="text" name="engine_hours" className="form-control" placeholder="Engine Hours" value=""/>
						</div>
						<div className="col-sm-3">
							<input type="text" required name="stock_number" className="form-control" placeholder="Stock Number *" value=""/>
						</div>
					
					</div>
					
					<div className="form-group">
						<label htmlFor="boat_brand" className="col-sm-2 control-label"></label>
						<div className="col-sm-3">
							<input type="text" className="form-control" id="boat_brand" placeholder="Boat Brand *" name="boat_brand" required/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" className="form-control" id="boat_type" name="boat_type" placeholder="Boat Type"/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" className="form-control" id="boat_class" name="boat_class" placeholder="Boat Class"/>
						</div>
					
					</div>
					
					<div className="form-group">
						<label htmlFor="frmboatPublished" className="col-sm-2 control-label">Status</label>
						<div className="col-sm-3">
							<select className="form-control" id="frmboatPublished" name="frmboatPublished">
								<option value="true">Published</option>
								<option value="false">Draft</option>
							</select>
						</div>
						
						<div className="col-sm-3">
							<input type="text" id="hull" name="hull" className="form-control" placeholder="Hull" value=""/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" name="hull_id" className="form-control" placeholder="Hull Id" value=""/>
						</div>
					
					</div>
					
					<div className="form-group">
						
						<label htmlFor="boat_condition" className="col-sm-2 control-label">Condition</label>
						<div className="col-sm-3">
							<select className="form-control" id="boat_condition" name="boat_condition">
								<option value="">Select</option>
								<option value="New">New Boat</option>
								<option value="Used">Used Boat</option>
							</select>
						</div>
						
						<div className="col-sm-3">
							<input type="text" id="fuel_type" name="fuel_type" placeholder="Fuel Type" className="form-control" />
						</div>
						
						<div className="col-sm-3">
							<input type="text" id="propulsion_type" name="propulsion_type" className="form-control" placeholder="Popultion Type"/>
						</div>
					
					</div>
					
					<div className="form-group">
						<label htmlFor="boat_year" className="col-sm-2 control-label"></label>
						<div className="col-sm-3">
							<input type="text" className="form-control" id="boat_year" name="boat_year" placeholder="Boat Year"/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" id="boat_make" name="boat_make" className="form-control" minLength="5" placeholder="Make" maxLength="200" value=""/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" id="boat_model" name="boat_model" className="form-control" minLength="5" placeholder="Model" maxLength="200" value=""/>
						</div>
					
					</div>
					
					<div className="form-group">
						<label htmlFor="boat_year" className="col-sm-2 control-label">Category</label>
						<div className="col-sm-3">
							<input type="text" name="category" className="form-control" placeholder="Category" value=""/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" name="dry_weight" className="form-control" placeholder="Dry Weight (lbs)" value=""/>
						</div>
						
						<div className="col-sm-3">
							<input type="text" name="capacity_weight" className="form-control" placeholder="Capcity allowed (lbs)" value=""/>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="frmboatPrice" className="col-sm-2 control-label">Sale price *</label>
						<div className="col-sm-6">
							<div className="input-group">
								<span className="input-group-addon">$</span>
								<input type="number" name="frmboatPrice" className="form-control" value="" step="any" required/>
							</div>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="frmboatPrice" className="col-sm-2 control-label">Retail price </label>
						<div className="col-sm-6">
							<div className="input-group">
								<span className="input-group-addon">$</span>
								<input type="number" name="frmboatRegularPrice" className="form-control" value="" step="any"/>
							</div>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="boat_is_featured" className="col-sm-2 control-label">Featured</label>
						<div className="col-sm-6">
							<select className="form-control" id="boat_is_featured" name="is_featured">
								<option value="" selected>Select</option>
								<option value="true">Yes</option>
								<option value="false">No</option>
							</select>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="boat_model_status" className="col-sm-2 control-label">Model Status</label>
						<div className="col-sm-6">
							<select className="form-control" id="boat_model_status" name="boat_model_status">
								<option value="" selected>Select</option>
								<option value="new_model">New Model</option>
								<option value="used_model">Used Model</option>
							</select>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="boat_sale_status" className="col-sm-2 control-label">Sale Status</label>
						<div className="col-sm-6">
							<select className="form-control" id="boat_sale_status" name="boat_sale_status">
								<option value="" selected>Select</option>
								<option value="for_sale">For Sale</option>
								<option value="pending_sale">Pending Sale</option>
								<option value="sold_delivered">Sold & Delivered</option>
								<option value="dealer_traded">Dealer Traded</option>
							</select>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="boat_length" className="col-sm-2 control-label">Boat Length</label>
						<div className="col-sm-2">
							<input type="number" className="form-control populate_length" id="boat_length_feet" name="boat_length_feet" placeholder="feet (ex: 12)"/>
						</div>
						<label className="col-sm-1 text-center">-</label>
						<div className="col-sm-2">
							<input type="number" className="form-control populate_length" id="boat_length_inch" name="boat_length_inch" placeholder="Inches (ex: 6)"/>
						</div>
						<label className="col-sm-1 text-center">=</label>
						<div className="col-sm-4">
							<input readOnly type="text" className="form-control" id="boat_length" name="boat_length" placeholder="0 FT 0 IN"/>
						</div>
					</div>
					
					<div className="form-group">
						<label htmlFor="beam_length" className="col-sm-2 control-label">Beam Length</label>
						<div className="col-sm-2">
							<input type="number" className="form-control populate_length" id="beam_length_feet" name="beam_length_feet" placeholder="feet (ex: 12)"/>
						</div>
						<label className="col-sm-1 text-center">-</label>
						<div className="col-sm-2">
							<input type="number" className="form-control populate_length" id="beam_length_inch" name="beam_length_inch" placeholder="Inches (ex: 6)"/>
						</div>
						<label className="col-sm-1 text-center">=</label>
						<div className="col-sm-4">
							<input readOnly type="text" className="form-control" id="beam_length" name="beam_length" placeholder="0 FT 0 IN"/>
						</div>
					</div>
					
					<div id="color-list"></div>
					
					<div className="form-group">
						<label htmlFor="" className="col-sm-2 control-label">Color Options</label>
						
						<div className="col-sm-4">
							<input type="text" className="form-control" id="option_name" name="option_name" placeholder="option name"/>
						</div>
						
						<div className="col-sm-4">
							<input type="text" className="form-control" id="option_value" name="option_value" placeholder="option value"/>
						</div>
						
						<div className="col-sm-2">
							<button className="btn pannel-btn btn-sm " type="button" onClick="add_color_field()">Add</button>
						</div>
					</div>
				</form>
			</div>
		);
	}
}

export default AddBoat
