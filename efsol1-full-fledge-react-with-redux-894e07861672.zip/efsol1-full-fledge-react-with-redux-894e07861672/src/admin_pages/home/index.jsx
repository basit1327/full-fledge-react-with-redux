/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */

import React from 'react';
import ChangeTitle from '../../components/change_page_title';
import AdminSidebar from '../admin-sidebar';
import {connect} from 'react-redux';

class Home extends React.Component {
	
	renderInsideComponent(){
		
		const NotFoundIllus = () => <div className="col-lg-10 col-md-10 col-sm-12 cap-error-page">
			<div id="notfound">
				<div className="notfound">
					<div className="notfound-404">
						<h1>Oops!</h1>
						<h2>404 - The Page can't be found</h2>
					</div>
				</div>
			</div>
		</div>;
		
		const AdminComponents = {
			AddProduct : require('../admin_components/AddProduct'),
			ListProduct : require('../admin_components/ListProduct'),
			AddBoat : require('../admin_components/AddBoat'),
			ListBoat : require('../admin_components/ListBoat'),
			AddEvent : require('../admin_components/AddEvent'),
			ListEvent : require('../admin_components/ListEvent'),
			AddUser : require('../admin_components/AddUser'),
			ListUser : require('../admin_components/ListUser'),
			EditMyAccount : require('../admin_components/EditMyAccount'),
			EmailNotification : require('../admin_components/EmailNotification'),
			EmailTemplateSetting : require('../admin_components/EmailTemplateSetting'),
			EmailSetting : require('../admin_components/EmailSetting'),
			GeneralSetting : require('../admin_components/GeneralSetting'),
		}
		
		if(this.props.adminState.selectedPage && AdminComponents[this.props.adminState.selectedPage]) {
			let Component = AdminComponents[this.props.adminState.selectedPage].default;
			return <Component/>
		}
		else {
			return <NotFoundIllus/>
		}
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				<ChangeTitle title={'Admin'}/>
				
				<nav className="navbar navbar-default navbar-static-top">
					<div className="container-fluid mainNavBar">
						<div className="navbar-header">
							<button type="button" className="navbar-toggle collapsed offcanvas-trigger" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
								<span className="sr-only">Toggle navigation</span>
								<span className="icon-bar"></span>
								<span className="icon-bar"></span>
								<span className="icon-bar"></span>
							</button>
							<a className="navbar-brand navbar-brand-image" href="/admin">
								<img className="img-responsive" style={{"width": "100%","padding": "20px;"}} alt="Wolf WaterSports of Arizona" src="assets/images/wolf-site-logo.png"/>
							</a>
						</div>
						<div id="navbar" className="navbar-collapse collapse">
							<ul className="nav navbar-nav navbar-right">
								<li><a href="/admin/logout"><i className="fa fa-sign-out" aria-hidden="true"> </i>Logout</a></li>
							</ul>
						</div>
					</div>
				</nav>
				
				<div className="container-fluid content-body">
					<div className="row admin-content-main-container">
						{/*SideBar*/}
						<div className="col-lg-2 col-md-3 col-sm-3 menu-top">
							<AdminSidebar/>
						</div>
						
						{/*Dynamic components below*/}
						<div className="col-lg-10 col-md-9 col-sm-9 tab_content">
							{this.renderInsideComponent()}
						</div>
					</div>
				</div>
				
			</React.Fragment>
		);
	}
}

function MapStateToProps(state) {
	return {adminState : state.adminReducer}
}

export default connect(MapStateToProps,null)(Home);


