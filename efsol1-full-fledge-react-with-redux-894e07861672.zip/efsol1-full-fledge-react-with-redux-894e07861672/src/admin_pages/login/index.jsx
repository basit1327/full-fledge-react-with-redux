import React from 'react';
import './style.css';
import $ from 'jquery';
import { adminLogin } from '../../utils/ajax_request';
import Swal from "sweetalert2";

class AdminLogin extends React.Component {
	
	componentDidMount () {
		if(localStorage.getItem('adminToken')&&localStorage.getItem('adminName')){
			Swal.fire({
				title: 'Already logged in',
				text: 'Redirecting you to dashboard',
				icon: 'success',
				showConfirmButton: false
			})
			setTimeout(()=>{window.location.href='/admin'},2000)
		}
	}
	
	async login(){
		try{
			if($('#inputEmail').val() && $('#inputPassword').val()){
				$('#loader').show();
				let res = await adminLogin(JSON.stringify({
					email : $('#inputEmail').val(),
					password : $('#inputPassword').val()
				}));
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 && res.hasOwnProperty('data') ) {
						localStorage.setItem('adminToken',res.data.token)
						localStorage.setItem('adminName',res.data.name)
						localStorage.setItem('adminRole',res.data.isAdmin?'Admin':'User')
						
						Swal.fire({
							title: 'Login Successful',
							text: 'Redirecting you to dashboard',
							icon: 'success',
							showConfirmButton: false
						})
						setTimeout(()=>{window.location.href='/admin'},2000)
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	render () {
		return (
			<React.Fragment>
				<div className="container">
					<ng-flash-message></ng-flash-message>
					<div className="card card-container">
						<img id="profile-img" className="profile-img-card" src="/assets/images/user_placeholder.png"/>
						<p id="profile-name" className="profile-name-card"></p>
						<div className="form-signin">
							<span id="reauth-email" className="reauth-email"></span>
								<input type="text" id="inputEmail" name="email" className="form-control" placeholder="Email" required autoFocus/>
								<div className="input-group">
									<input type="password" id="inputPassword" name="password" className="form-control mb-0" placeholder="Password" required/>
									<span className="input-group-addon">
										<a href="javascript:void(0)" onClick="(function(){
											  if(document.getElementById('inputPassword').type == 'text'){
												document.getElementById('inputPassword').type='password';
											  } else {
												document.getElementById('inputPassword').type='text';
											  }
											  return false;
											})();return false;">
											<i className="fa fa-eye"></i>
										</a>
									</span>
								</div>
								<div id="remember" className="checkbox">
									<label>
										<input type="checkbox" value="remember-me" checked/> Remember me
									</label>
								</div>
								<button className="btn btn-lg btn-primary btn-block btn-signin" onClick={this.login.bind(this)}>Admin Sign in</button>
						</div>
						<a href="#" className="forgot-password">
							Forgot the password?
						</a>
					</div>
				</div>
			</React.Fragment>
		);
	}
}

export default AdminLogin;
