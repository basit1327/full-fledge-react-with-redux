/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';
import { userApiCall } from '../../utils/ajax_request';
import $ from 'jquery';
import Swal from "sweetalert2";
import parse from 'html-react-parser';
import Notifications, {notify} from 'react-notify-toast';
import { alphabets,
	alphaNumeric,
	numeric,
	validateEmail,
	validatePhoneNumber,
	validateTime,
	validateDate,
	validateFloat } from '../../utils/validator';

/* OwlCarousel */
import OwlCarousel from 'react-owl-carousel2';
import 'react-owl-carousel2/src/owl.carousel.css';

class BoatDetail extends React.Component {
	
	breadcrumbNavigation = [
		{
			title:'Boat Detail',
			link:'#'
		}
	]
	state = {
		recentlyViewedBoats:null,
		boatDetail: null,
		boatId: null,
	}
	
	async componentWillMount () {
		if(!this.state.boatDetail){
			let urlParams = new URLSearchParams(window.location.search);
			urlParams = urlParams.toString().split('=');
			if(urlParams.length>0){
				this.setState({ boatId : urlParams[1]});
			}
			this.getBoatDetail(urlParams[1])
		}
	}
	
	async getBoatDetail(boatId){
		try{
			if(boatId){
				let res = await userApiCall('get_boat_by_id?id='+boatId);
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 && res.hasOwnProperty('data') ) {
						this.setState({ boatDetail : res.data});
						this.appendRecentlyViewedBoats(res.data)
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
			else {
				Swal.fire({
					title: 'Error!',
					text: 'No record found, as no boat id is provided',
					icon: 'error',
				})
			}
		}
		catch ( e ){
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	submitContactRequest = ()=>{
		let body = {};
		$("form#contact-form :input").each(function(){
			let input = $(this);
			body[input.attr("name")] = input.val()
		});

		body['comments'] = $('comments').val();

		notify.show('Great! You request has been submitted','success');

		$("form#contact-form :input").each(function(){
			let input = $(this);
			body[input.attr("name")] = input.val("")
		});
		$('comments').val('');
		return;
	}
	
	appendRecentlyViewedBoats = (boat)=>{
		try{
			let recentlyViewedBoats = localStorage.getItem('recentlyViewedBoats');
			if(recentlyViewedBoats){
				recentlyViewedBoats = JSON.parse(recentlyViewedBoats);
				if(recentlyViewedBoats.length>0){
					let matchedIds = recentlyViewedBoats.filter((e) => {
					  return e._id === boat._id;
					});
					if(matchedIds.length===0){
						recentlyViewedBoats.push(boat);
						localStorage.setItem('recentlyViewedBoats',JSON.stringify(recentlyViewedBoats));
					}
				}
				else if(recentlyViewedBoats.length===0){
					recentlyViewedBoats = [];
					recentlyViewedBoats.push(boat);
					localStorage.setItem('recentlyViewedBoats',JSON.stringify(recentlyViewedBoats));
				}
			}
			else {
				recentlyViewedBoats = [];
				recentlyViewedBoats.push(boat);
				this.setState({ recentlyViewedBoats : recentlyViewedBoats});
				localStorage.setItem('recentlyViewedBoats',JSON.stringify(recentlyViewedBoats));
			}
		}
		catch (e){
			console.log(e);
		}
	}
	
	getRecentlyViewedBoats = ()=>{
		try{
			let recentlyViewedBoats = localStorage.getItem('recentlyViewedBoats');
			if(recentlyViewedBoats){
				recentlyViewedBoats = JSON.parse(recentlyViewedBoats);
				return recentlyViewedBoats;
			}
			else {
				return []
			}
		}
		catch (e){
			console.log(e);
			this.setState({ recentlyViewedBoats : []});
		}
	}
	
	renderRecentlyViewedBoats(){
		const rb = [];
		const max = 2;
		let rb_data = this.getRecentlyViewedBoats();
		for ( const [index, element] of rb_data.entries() ) {
			if(rb.length>=max){
				break;
			}
			if(this.state.boatDetail && element._id != this.state.boatDetail._id){
				console.log(element);
				rb.push(
					<div className="related_posts">
						<div className="event_img_frame event_img_frame_right">
							<a href={'#'} onClick={() => this.setState({boatDetail:element})}> <img src={element.boatImages.length>0? element.boatImages[0].image:'assets/images/placeholder.jpg'} className="img-fluid"/> </a>
						</div>
						<a href={'#'} onClick={() => this.setState({boatDetail:element})}> <h4>{element.boat_make} {element.boat_model} {element.boat_year}</h4> </a>
						<p><strong>${element.boatPrice}</strong></p>
					</div>
				);
			}
		}
		return rb;
	}
	
	renderContactForm(){
		return(
			<form id='contact-form'>
				<div className="row">
					<div className="col-12">
						<div className="form-group">
							<label>Name*</label>
							<input type="text" onChange={alphabets.bind(this)} name="name" id={"name"} className="form-control" placeholder="Name"/>
						</div>
					</div>
					<div className="col-12">
						<div className="form-group">
							<label>Email*</label>
							<input type="text" onChange={validateEmail.bind(this)} name="email" id="email" className="form-control" placeholder="Email"/>
						</div>
					</div>
					<div className="col-12">
						<div className="form-group">
							<label>Phone*</label>
							<input type="text" onChange={validatePhoneNumber.bind(this)} name="phone" id="phone" className="form-control" placeholder="Phone"/>
						</div>
					</div>
					<div className="col-12">
						<div className="form-group">
							<label>Comments*</label>
							<textarea rows="5" onChange={alphaNumeric.bind(this)} name="comments" id="comments" className="form-control" placeholder="Comments"></textarea>
						</div>
					</div>
					
					<div className="col-12">
						<div className="form-group text-center">
							<input type="button" className={'submit_btn'} name="button" onClick={this.submitContactRequest} value="Submit"/>
						</div>
					</div>
				</div>
			</form>
		)
	}
	
	parseBoatDescriptionHtml(){
		return parse(this.state.boatDetail.boatDescription)
	}
	
	renderBoatDetail(){
		const options = {
			margin:5,
			autoWidth:true,
			autoHeight:true,
			autoplay:true,
			items: 3,
			// nav: true,
			// rewind: true,
			dots:true,
			loop:true,
			autoplaySpeedL:true
		};
		
		let boatCarousel = (images)=>{
			let items = []
			images.forEach(e=>{
					items.push(<img src={e.image} className="img-fluid"/>)
			});
			return (
				<OwlCarousel ref="car" options={options}>
					{items}
				</OwlCarousel>
			)
		}
		
		if(this.state.boatDetail){
			return(
				<React.Fragment>
					<div className="col-lg-8 col-md-8 col-sm-12 col-xs-12">
						<p className="years"><span><a href="#">{this.state.boatDetail.boatTitle}</a></span>
							<span className="pull-right call-price"><a href="#">{this.state.boatDetail.boatPrice?this.state.boatDetail.boatPrice+'K':'Call For Pricing'}</a>
											<ul className="socail_icons share_btn pull-right list-styled-none">
											<li>
												<div className="dropdown">
													<button className="btn btn-share dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown"
														aria-haspopup="true" aria-expanded="false">
														Shar <i className="fa fa-share-alt"></i>
													</button>
													<div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
														<ul className="list-styled-none">
															<li><a className="dropdown-item" href="#"><i className="fa fa-facebook-f"></i>Facebook</a></li>
															<li> <a className="dropdown-item" href="#"><i className="fa fa-twitter"></i>Twitter</a></li>
															<li><a className="dropdown-item" href="#"><i className="fa fa-envelope"></i>Email</a></li>
														   </ul>
													</div>
												</div>
											</li>
											</ul>
                            			</span>
						</p>
						<div className="row">
							<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
								<div className='event_wrapper'>
									<div className="event_img_frame_new">
										{boatCarousel(this.state.boatDetail.boatImages)}
									</div>
									<div className="slider_tumbnails section-strt">
										<ul id="three" className="owl_style owl-carousel owl-theme">
											<li className="item">
												<img src="assets/images/detail-img.jpg"/>
											</li>
										</ul>
									</div>
									<div className="owl-controls clickable">
										<div className="owl-pagination">
											<div className="owl-page"><span className=""></span></div>
											<div className="owl-page active"><span className=""></span></div>
										</div>
										<div className="owl-buttons">
											<div className="owl-prev">prev</div>
											<div className="owl-next">next</div>
										</div>
									</div>
									<div className="event_content section-strt">
										<div className="row">
											<div className="col-md-12 col-lg-12 col-sm-12 col-xs-12 col-12">
												<div className="article_detail">
													<div className="article_title">
														<ul className="nav nav-tabs" id="myTab" role="tablist">
															<li className="nav-item">
																<a className="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
																	aria-selected="true">DESCRIPTION</a>
															</li>
														</ul>
														<div className="tab-content">
															<div className="tab-pane fade active in" id="home" role="tabpanel" aria-labelledby="home-tab">
																{this.parseBoatDescriptionHtml()}</div>
														</div>
														<ul className="nav nav-tabs">
															<li className="nav-item">
																<a className="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab"
																	aria-controls="profile" aria-selected="false">SPECS</a>
															</li>
														</ul>
														
														<div className="tab-content">
															<div className="tab-pane fad active in" id="profile" role="tabpanel" aria-labelledby="profile-tab">
																<div className="row">
																	<div className="col-lg-4 col-md-4 col-sm-6 col-12">
																		<div className="col-wrapper">
																			<h2>Brand</h2>
																			<h3>{this.state.boatDetail.boat_brand}</h3>
																		</div>
																	</div>
																	<div className="col-lg-4 col-md-4 col-sm-6 col-12">
																		<div className="col-wrapper">
																			<h2>Class</h2>
																			<h3>{this.state.boatDetail.boat_class}</h3>
																		</div>
																	</div>
																	<div className="col-lg-4 col-md-4 col-sm-6 col-12">
																		<div className="col-wrapper">
																			<h2>Model</h2>
																			<h3>{this.state.boatDetail.boat_model}</h3>
																		</div>
																	</div>
																</div>
																<div className="row">
																	<div className="col-lg-4 col-md-4 col-sm-6 col-12">
																		<div className="col-wrapper">
																			<h2>Year</h2>
																			<h3>{this.state.boatDetail.boat_year}</h3>
																		</div>
																	</div>
																	<div className="col-lg-4 col-md-4 col-sm-6 col-12">
																		<div className="col-wrapper">
																			<h2>CONDITION</h2>
																			<h3>{this.state.boatDetail.boat_condition}</h3>
																		</div>
																	</div>
																	<div className="col-lg-4 col-md-4 col-sm-6 col-12">
																		<div className="col-wrapper">
																			<h2>STOCK NUMBER</h2>
																			<h3>{this.state.boatDetail.stock_number}</h3>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="col-lg-4 col-md-4 col-sm-12 col-12">
						<div className="row">
							<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
								<div className="contact-info-title">
									<h2>Contact Us</h2>
								</div>
								<div className='event_wrapper'>
									<div className="event_content event_content_right ">
										<div className="contact_wrapper">
											{/* Rendering contact form */}
											{this.renderContactForm()}
										</div>
										<div className="schedule_links">
											<ul>
												<a href="#"> Schedule a demo</a>
												<a href="#"> Calculate payment</a>
												<a href="#"> Get Pre-Approved</a>
											</ul>
										</div>
										<h3 className="schedule_links">Recently Viewed</h3>
										
										{/* Rendering recently viewed boats	*/}
										{this.renderRecentlyViewedBoats()}
									</div>
								
								</div>
							</div>
						
						</div>
					</div>
				</React.Fragment>
			)
		}
		else if(this.state.boatId) {
			$('#loader').show();
			return
		}
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'Boat detail'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<Notifications />
					<section className="parts_top section-strt ">
						<div className="container">
							{/* Breadcrumb */}
							<BreadCrumb title={''} navigation={this.breadcrumbNavigation}/>
						</div>
					</section>
					<section class=" resource_article_section product-detail_section section-strt">
						<div class="container">
							<div class="row">
								{this.renderBoatDetail()}
							</div>
						</div>
					</section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
			</React.Fragment>
		);
	}
}

export default BoatDetail;

