/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';


class ArticleDetail extends React.Component {
	
	breadcrumbNavigation = [
		{
			title:'Article Detail',
			link:'#'
		}
	]
	
	eventsData = [
		{
			title:'Lorem ipsum',
			date:'October 14 @ 11:00am - 5:00pm',
			text:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.'
		},
		{
			title:'Why do we use it?',
			date:'October 15 @ 11:00am - 5:00pm',
			text:'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters,'
		}
	]
	
	renderSideEvents(){
		const events = [];
		for ( const [index, element] of this.eventsData.entries() ) {
			events.push(
				<div className="col-12">
					<div className="form-group">
						<div className="event-tile"><h2>{element.title}</h2></div>
						<div className="event-date"><span>{element.date}</span></div>
						<p>{element.text}</p>
						<a href="#">Read more >></a>
					</div>
				</div>
			);
		}
		return events;
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'Article detail'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<section class="parts_top section-strt ">
						<div class="container">
							{/* Breadcrumb */}
							<BreadCrumb title={''} navigation={this.breadcrumbNavigation}/>
						</div>
					</section>
					
					<section class=" resource_article_section product-detail_section article-detail-sec section-strt">
						<div class="container">
							<div class="row">
								<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
									<p class="years"><span><a href="#">Article Title</a></span>
										<span class="pull-right call-price"><a href="#">October 14 @ 11:00am - 5:00pm</a>
											<br/>
											<ul class="socail_icons share_btn pull-right list-styled-none">
												<li>
													<div class="dropdown">
														<a href="#">Article title next >> </a>
													</div>
												</li>
											</ul>
                            			</span>
									</p>
									<div class="row">
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
											<div class='event_wrapper'>
												<div class="event_img_frame">
													<img src="assets/images/detail-img.jpg" class="img-fluid"/>
												</div>
												<div class="event_content section-strt">
													<div class="row">
														<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 col-12">
															<div class="article_detail section-strt">
																<div class="section-strt">
																	<div class="event-tile pull-left"><h2>Posted October 01, 2019</h2></div>
																	<div class="event-date pull-right">
																		<span><a href="#"><i hidden="hidden">Facebook</i><i class="fa fa-facebook-f"></i></a></span>
																		<span><a href="#"><i hidden="hidden">Instagram</i><i class="fa fa-instagram"></i></a></span>
																		<span><a href="#"><i hidden="hidden">Youtube</i><i class="fa fa-youtube"></i></a></span>
																	</div>
																</div>
																<div class="art-description">
																	<ul>
																		<li><strong>Location: </strong> <strong>Wolf WaterSports, Mesa</strong></li>
																		<li><strong>Date: </strong> <strong>October 14, 2019</strong></li>
																		<li><strong>Hours:</strong> <strong> 11:00am-5:00pm</strong></li>
																	</ul>
																	<p>
																		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
																		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?
																		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
																	</p>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-12 col-12">
									<div class="row">
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
											<div class='event_wrapper'>
												<div class="event_content event_content_right ">
													<div class="contact_wrapper">
														<form>
															<div class="row">
																{this.renderSideEvents()}
															</div>
														</form>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
				    </section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
			</React.Fragment>
		);
	}
}

export default ArticleDetail;

