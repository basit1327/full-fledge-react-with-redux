/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';
import $ from 'jquery';
import Notifications, {notify} from 'react-notify-toast';
import { alphabets,
	alphaNumeric,
	numeric,
	validateEmail,
	validatePhoneNumber,
	validateTime,
	validateDate,
	validateFloat } from '../../utils/validator';

class Service extends React.Component {
	
	breadcrumbNavigation = [
		{
			title:'Service',
			link:'#'
		}
	]
	
	submitServiceRequest = ()=>{
		let data = {
			firstName : $('#firstName').val(),
			lastName : $('#lastName').val(),
			phoneNo : $('#phoneNo').val(),
			email : $('#email').val(),
			preferredDate : $('#preferredDate').val(),
			preferredTime : $('#preferredTime').val(),
			year : $('#year').val(),
			make : $('#make').val(),
			model : $('#model').val(),
			hullId : $('#hullId').val(),
			hours : $('#hours').val(),
			comments : $('#comments').val()
		}
		for(let key in data){
			if(!data[key]){
				notify.show('Please fill all required fields','error');
				return;
			}
		}
		notify.show('Great! You request has been submitted','success');
		
		//Clearing
		$('#firstName').val('');
		$('#lastName').val('');
		$('#phoneNo').val('');
		$('#email').val('');
		$('#preferredDate').val('');
		$('#preferredTime').val('');
		$('#year').val('');
		$('#make').val('');
		$('#model').val('');
		$('#hullId').val('');
		$('#hours').val('');
		$('#comments').val('')
		
		console.log(data);
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'Service'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<Notifications />
					<section className="parts_top section-strt contact">
						<div className="container">
							{/* Breadcrumb */}
							<BreadCrumb navigation={this.breadcrumbNavigation}/>
						</div>
					</section>
					<section className="contact-section section-strt contact">
						<div className="container">
							<div className="col-lg-8 col-md-8 col-xs-12">
								<div className="parts_title">
									<h1>WOLF WATERSPORTS SERVICE CENTER</h1>
									<p>The credibility of our Service Department is absolutely astounding. Specializing in stock and high-performance services, Wolf Watersports has you covered. We are the exclusive MasterCraft Boat Company and Ilmor Marine Engines service center in Arizona. We are equipped to make your boat suitable for you and your taste. We have top factory-trained technicians who have completed their training yearly.</p>
									<p>We honor all warranty work and favor any recalls. We accommodate any type of problem that may arise with your boat in an efficient, precise, and timely manner. The exclusive MasterCraft Dealer and Service Center in Arizona. Wolf Watersports also services all makes and models from Nautique, Malibu, MB Sports, Tige, Moomba, Supra, Supreme, and Centurion.</p>
								</div>
								<img alt="sidepanel image" src="/assets/images/lgo.jpg" className="img-responsive"
									style={{'width':'200px', 'height':'23px', 'marginTop':'50px', 'marginBottom':'50px'}}/>
									
									<div className="section-form">
										<div >
											<div className="row">
												<div className="col-xs-12 text-center request-form">
													<h2>Request form</h2>
												</div>
												<div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12">
													<div className="row general-struct-forms">
														<div className="col-lg-12 col-md-12 col-xs-12">
															<div className="form-group">
																<h2>Contact Info:</h2>
															</div>
														</div>
														<div className="contact_wrapper">
															<div className="row">
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="firstNameLabel" htmlFor="firstName"> First Name </label>
																		<input onChange={alphabets.bind(this)} name="firstName" className="form-control"
																			aria-labelledby="firstNameLabel" placeholder="First Name*" type="text"
																			aria-labelledby="first_nameLabel" id="firstName"/>
																	</div>
																</div>
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="lastNameLabel" htmlFor="lastName"> Last Name </label>
																		<input onChange={alphabets.bind(this)} name="lastName" type="text" className="form-control"
																			aria-labelledby="lastNameLabel" placeholder="Last Name*"
																			aria-labelledby="Last_nameLabel" id="lastName"/>
																	</div>
																</div>
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="phoneNoLabel" htmlFor="phoneNo"> Phone No </label>
																		<input onChange={validatePhoneNumber.bind(this)} name="phoneNo" type="text" className="form-control"
																			placeholder="Phone*" aria-labelledby="phoneNoLabel" id="phoneNo" required/>
																	</div>
																</div>
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="EmailLabel" htmlFor="Email"> Email </label>
																		<input onChange={validateEmail.bind(this)} name="email" className="form-control" placeholder="Email*"
																			type="email" aria-labelledby="EmailLabel" id="email" required/>
																	</div>
																</div>
																<div className="col-md-12">
																	<div className="billing_address">
																		<h2>Appointment info:</h2>
																	</div>
																</div>
																<div className="col-md-12">
																	<div className="form-group clearfix">
																		<label id="Service_DateLabel" htmlFor="Service_Date"> Service Date </label>
																		<input type='date' className="form-control" name="preferredDate" placeholder="Preferred Date"
																			aria-labelledby="Service_DateLabel" id='preferredDate'/>
																	</div>
																</div>
																<div className="col-md-12">
																	<div className="form-group clearfix">
																		<label id="Best_TimeLabel" htmlFor="Best_TimeLabel"> Best Time </label>
																		<input type="text" aria-labelledby="Best_TimeLabel" name="preferredTime" className="form-control"
																			placeholder="Preferred Time" id="preferredTime"/>
																	</div>
																</div>
															
															</div>
														</div>
													</div>
												</div>
												<div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12">
													<div className="row general-struct-forms">
														<div className="contact_wrapper">
															<h2>About Your boat:</h2>
															<div className="row">
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="YearLabel" htmlFor="Year"> Year </label>
																		<input id="year" type="text" name="year" aria-labelledby="YearLabel"
																			onChange={numeric.bind(this)} className="form-control" placeholder="Year*"/>
																	</div>
																</div>
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="Boat_MakeLabel" htmlFor="BoatMake"> Boat Make </label>
																		<input onChange={alphaNumeric.bind(this)} name="make" className="form-control" placeholder="Make*"
																			type="text" aria-labelledby="Boat_MakeLabel" id="make" required/>
																	</div>
																</div>
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="Boat_ModelLabel" htmlFor="Boat_Model"> Boat Model </label>
																		<input onChange={alphaNumeric.bind(this)} name="model" className="form-control" placeholder="Model*"
																			type="text" aria-labelledby="Boat_ModelLabel" id="model" required/>
																	</div>
																</div>
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="boat-hullIdLabel" htmlFor="boat-hullId"> Boat Hull Id</label>
																		<input type="text" id="hullId" aria-labelledby="boat-hullIdLabel" name="hullId"
																			className="form-control" placeholder="Hull ID"/>
																	</div>
																</div>
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="Hours_on_BoatLabel" htmlFor="Hours_on_Boat"> Hours on Boat</label>
																		<input name="hours" type="text" className="form-control" placeholder="Hours"
																			aria-labelledby="Hours_on_BoatLabel" id="hours" required/>
																	</div>
																</div>
																<div className="col-12">
																	<div className="form-group clearfix">
																		<label id="Additional_CommentsLabel" htmlFor="Additional_Comments"> Additional Comments</label>
																		<textarea type="text" name="comments" className="form-control" placeholder="Comments "
																			aria-labelledby="Additional_CommentsLabel" id="comments" required/>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div className="col-12">
												<div className="form-group clearfix pull-left">
													<input type="button" id="schedule-demo" className={'btn btn-primary'} name="submit" onClick={this.submitServiceRequest} value="SUBMIT"/>
												</div>
											</div>
										</div>
									</div>
							</div>
							<div className="col-lg-4 col-md-6 col-sm-12 col-xs-12">
								<div className="side-img">
									<a href="#">
										<img alt="sidepanel image" src="/assets/images/side-panel.jpg" className="img-responsive"/>
									</a>
								</div>
								<div className="section-form">
									<div className="right-content">
										<h3>Hours Operation</h3>
										<ul>
											<li><strong>Sunday</strong> <span>Closed</span></li>
											<li><strong>Monday</strong> <span>9:00AM - 6:00PM</span></li>
											<li><strong>Tuesday</strong> <span>9:00AM - 6:00PM</span></li>
											<li><strong>Wednesday</strong> <span>9:00AM - 6:00PM</span></li>
											<li><strong>Thursday</strong> <span>9:00AM - 6:00PM</span></li>
											<li><strong>Friday</strong> <span>9:00AM - 6:00PM</span></li>
											<li><strong>Saturday</strong> <span>10:00AM - 4:00PM</span></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
				
			</React.Fragment>
		);
	}
}

export default Service;

