/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import FeaturedBoat from '../../components/featured_boat';
import SingleNews from '../../components/single_news';
import ChangeTitle from '../../components/change_page_title';
import { userApiCall } from '../../utils/ajax_request';
import Swal from 'sweetalert2'

class Home extends React.Component {
	
	state = {
		featuredBoats : [],
		news : []
	}
	
	async componentWillMount () {
		this.getFeaturedBoatsData()
		this.getLatestNewsData()
	}
	
	async getFeaturedBoatsData(){
		try{
			let x = localStorage.getItem('featured_boats');
			if(x){
				x = JSON.parse(x);
				this.setState({ featuredBoats : x});
			}
			else {
				let res = await userApiCall('get_featured_boat?count=4');
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 && res.hasOwnProperty('data') ) {
						localStorage.setItem('featured_boats',JSON.stringify(res.data))
						this.setState({ featuredBoats : res.data});
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
		}
		catch ( e ){
			console.log(e);
		}
	}
	
	async getLatestNewsData(){
		try{
			let x = localStorage.getItem('latest_news');
			if(x){
				x = JSON.parse(x);
				this.setState({ news : x});
			}
			else {
				let res = await userApiCall('get_latest_news?count=3');
				if (!res) {
					Swal.fire({
						title: 'Error!',
						text: 'Something went wrong..',
						icon: 'error',
					})
					return false;
				}
				if ( res.hasOwnProperty('status') ) {
					if ( res.status == 200 && res.hasOwnProperty('data') ) {
						localStorage.setItem('latest_news',JSON.stringify(res.data))
						this.setState({ news : res.data});
					} else if ( res.status == 400 ) {
						Swal.fire({
							title: 'Error!',
							text: res.message,
							icon: 'error',
						})
					}
				}
			}
		}
		catch ( e ){
			console.log(e);
		}
	}
	
	renderFeaturedBoats(){
		const fb = [];
		for ( const [index, element] of this.state.featuredBoats.entries() ) {
			fb.push(
				<FeaturedBoat _id={element._id}  key={index} year={element.boat_year} make={element.boat_make} model={element.boat_model} length={element.boat_length} productImage={element.productImage}/>
			);
		}
		return fb;
	}
	
	renderNews(){
		const _news = [];
		for ( const [index, element] of this.state.news.entries() ) {
			_news.push(
				<SingleNews _id={element._id} key={index} title={element.eventTitle} text={element.eventDescription} month={element.eventMonth} date={element.eventYear}/>
			);
		}
		return _news;
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>

				<ChangeTitle title={'Home'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<section class="section-strt">
						<div class="section-strt video_frame">
							<img src="assets/images/temprary-img.jpg" class="img-responsive"/>
						</div>
					</section>
					
					{/*Render featured boats*/}
					<section class="section-strt featured_boats">
						<div class="container">
							<div class="row">
								<div class="col-12 text-center">
									<h2>Featured Boats</h2>
								</div>
							</div>
							<div class="row1">
								{/*Render featured boats*/}
								{this.renderFeaturedBoats()}
								<div class="row">
									<div class="col-12 text-center view-invent">
										<a href={'/inventory'}>View All Inventory</a>
									</div>
								</div>
							</div>
						</div>
					</section>
					
					{/* Service/Value-Trades banners */}
					<section class="section-strt">
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12">
									<div class="row">
										<a href={'/inventory'} class="images_box">
											<div class="overlay-on-img"></div>
											<div class="boats-img-frame boats-img-frame_right">
												<img src="assets/images/boats-images5.jpg"/>
											</div>
											<h2>Surf</h2>
										</a>
									</div>
								</div>
								<div class="col-lg-7 col-md-6 col-sm-6 col-xs-12">
									<div class="row">
										<a href={'/inventory'} class="images_box">
											<div class="overlay-on-img"></div>
											<div class="boats-img-frame ">
												<img src="assets/images/boats-images6.jpg"/>
											</div>
											<h2>Inventory</h2>
										</a>
									</div>
								</div>
							</div>
						</div>
					</section>
					<section class="section-strt">
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-7 col-md-6 col-sm-6 col-xs-12">
									<div class="row">
										<a href={'/service'} class="images_box">
											<div class="overlay-on-img"></div>
											<div class="boats-img-frame">
												<img src="assets/images/boats-images1.jpg"/>
											</div>
											<h2>Service</h2>
										</a>
									</div>
								</div>
								<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12">
									<div class="row">
										<a href={'/parts_request'} class="images_box">
											<div class="overlay-on-img"></div>
											<div class="boats-img-frame boats-img-frame_right">
												<img src="assets/images/boats-images2.jpg"/>
											</div>
											<h2>Parts</h2>
										</a>
									</div>
								</div>
							</div>
						</div>
					</section>
					<section class="section-strt">
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12">
									<div class="row">
										<a href={'/loan_calculator'} class="images_box">
											<div class="overlay-on-img"></div>
											<div class="boats-img-frame boats-img-frame_right">
												<img src="assets/images/boats-images3.jpg"/>
											</div>
											<h2>Get Financing</h2>
										</a>
									</div>
								</div>
								<div class="col-lg-7 col-md-6 col-sm-6 col-xs-12">
									<div class="row">
										<a href={'/loan_calculator'} class="images_box">
											<div class="overlay-on-img"></div>
											<div class="boats-img-frame ">
												<img src="assets/images/boats-images4.jpg"/>
											</div>
											<h2>Value your trade</h2>
										</a>
									</div>
								</div>
							</div>
						</div>
					</section>
					
					{/* News/Events	*/}
					<section className="section-strt featured_boats">
						<div className="container">
							<div className="row">
								<div className="col-12 text-center">
									<h2>News & Events</h2>
								</div>
							</div>
							<div className="row1">
								{this.renderNews()}
								<div className="row">
									<div className="col-12 text-center view-invent pull-right more-news">
										<a href={'/news_events'}>More News & Events ></a>
									</div>
								</div>
							</div>
						</div>
					
					</section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
			</React.Fragment>
		);
	}
}

export default Home;

