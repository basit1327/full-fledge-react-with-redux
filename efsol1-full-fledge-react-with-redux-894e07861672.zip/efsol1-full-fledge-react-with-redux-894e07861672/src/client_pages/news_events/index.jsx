/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';
import { userApiCall } from '../../utils/ajax_request';
import Swal from "sweetalert2";

class NewsEvents extends React.Component {
	
	breadcrumbNavigation = [
		{
			title:'News & Events',
			link:'#'
		}
	]
	
	state = {
		events : [],
		months : [
			'January',
			'February',
			'March',
			'April',
			'May',
			'June',
			'July',
			'August',
			'September',
			'October',
			'November',
			'December'
		],
		selectedMonth : ''
	}
	
	async componentWillMount () {
		if(this.state.events.length==0){
			this.getLatestNewsData()
		}
	}
	
	monthChange = (event)=>{
		this.setState({ selectedMonth:event.target.value});
	}
	
	async getLatestNewsData(){
		try{
			let res = await userApiCall('get_events?skip=0');
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({ events : res.data});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			console.log(e);
		}
	}
	
	renderMonths(){
		let m = [];
		for ( const [index, element] of this.state.months.entries() ) {
			m.push(<option value={element}>{element}</option>)
		}
		return m;
	}
	
	renderYearsTab(){
		let tabs = [];
		for ( const [index, element] of this.state.events.entries() ) {
			if(index==0){ tabs.push(<li className="active"><a data-toggle="tab" href={'#'+element.year}>{element.year}</a></li>)}
			else{ tabs.push(<li><a data-toggle="tab" href={'#'+element.year}>{element.year}</a></li>) }
		}
		return tabs;
	}
	
	renderTabContent(){
		
		let renderSubContentInner = (dataByMonth)=>{
			let contentByMonth = [];
			for ( const [index, element] of dataByMonth.entries() ) {
				if(element.eventMonth.toLowerCase().includes(this.state.selectedMonth.toLowerCase())){
					contentByMonth.push(
						<div className="col-lg-12">
							<div className="col-lg-8 col-md-6 col-sm-12 col-xs-12">
								<form>
									<div className="row general-struct-forms">
										<div className="">
											<div className="form-group">
												<div className="event-tile"><h2>{element.eventTitle}</h2></div>
												<div className="event-date"><span>{element.eventDate+' '+element.eventMonth}</span></div>
												<p>{element.eventDescription}</p>
												<a href={"/event_detail?id="+element._id}>Find out more >></a>
											</div>
										</div>
									</div>
								</form>
							</div>
							<div className="col-lg-4 col-md-6 col-sm-12 col-xs-12">
								<div className="right-content">
									<div className="img-frame">
										<img src={element.eventImages.length>0?element.eventImages[0]:'assets/images/placeholder.jpg'} className="img-responsive" alt="map-image"/>
									</div>
								</div>
							</div>
						</div>
					)
				}
			}
			return contentByMonth;
		}
		
		let renderSubContent = (year,data)=>{
			let subContent = [];
			for ( const [index, element] of data.entries() ) {
				subContent.push(
					<React.Fragment>
						<a href={'#sub_content'+element.month} className="btn btn-info" data-toggle="collapse">{this.state.selectedMonth?this.state.selectedMonth+' ' + +year : element.month +' ' + +year}</a>
						<div id={'#sub_content'+element.month} className="collapsed">
							{renderSubContentInner(element.data)}
						</div>
					</React.Fragment>
				)
			}
			return subContent;
		}
		
		let contents = [];
		for ( const [index, element] of this.state.events.entries() ) {
			contents.push(
				<div id={element.year} className={index==0?'tab-pane fade in active':'tab-pane fade'}>
					{renderSubContent(element.year,element.data)}
				</div>
			)
		}
		return contents;
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'News/Events'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<section className="parts_top section-strt contact">
						<div className="container">
							{/* Breadcrumb */}
							<BreadCrumb title={'News & Events'} navigation={this.breadcrumbNavigation}/>
						</div>
					</section>
					<section className="contact-section newsevent-sec section-strt">
						<div className="container">
							<div className="row">
								<div className="col-lg-12 col-xs-12">
									<ul className="nav nav-tabs">
										{this.renderYearsTab()}
										<li>
											<select class="form-control month-selector" onChange={this.monthChange}>
												<option selected={'selected'} value={''}>--select month--</option>
												{this.renderMonths()}
											</select>
										</li>
									</ul>
									<div className="tab-content">
										{this.renderTabContent()}
									</div>
								</div>
							</div>
						</div>
					</section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
				
			</React.Fragment>
		);
	}
}

export default NewsEvents;

