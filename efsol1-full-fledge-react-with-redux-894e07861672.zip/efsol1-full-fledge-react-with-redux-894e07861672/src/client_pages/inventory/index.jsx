/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';
import $ from 'jquery';
import { userApiCall } from '../../utils/ajax_request';
import Swal from "sweetalert2";
import Pagination from "react-js-pagination";
import InputRange from 'react-input-range';
import 'react-input-range/lib/css/index.css'

class Inventory extends React.Component {
	
	breadcrumbNavigation = [
		{
			title:'Inventory',
			link:'/inventory'
		},
		{
			title:'New Boats',
			link:'#'
		}
	]
	
	state = {
		filters:{
			beep:false,
			searchKeyword:'',
			condition:[],
			sortBy:'Descending',
			selectedBrands:[],
			lengthRange:{min:0,max:100},
			yearRange:{min:1999,max:2050},
			priceRange:{min:0,max:10000000}
		},
		allConditions:['New','Used'],
		allSorts:['Ascending','Descending'],
		allBrands:[],
		inventoryBoats:[],
		pagination:{
			currentPage:1,
			totalPages:14,
		},
		lengthRange: {
			min: 0,
			max: 0
		},
		lengthRangeSelected: {
			min: 0,
			max: 0
		},
		priceRange: {
			min: 0,
			max: 0
		},
		priceRangeSelected: {
			min: 0,
			max: 0
		},
		yearRange: {
			min: 0,
			max: 0
		},
		yearRangeSelected: {
			min: 0,
			max: 0
		},
	}
	
	async componentWillMount () {
		this.getBoatsData();
		this.getBoatBrands();
		this.getRangesData();
	}
	
	async componentWillUpdate ( nextProps, nextState, nextContext ) {
		if(this.state.pagination.currentPage !== nextState.pagination.currentPage){
			let filters = {...this.state.filters}
			filters.beep = !this.state.filters.beep
			this.setState({filters})
			return true
		}
	}
	
	async shouldComponentUpdate ( nextProps, nextState, nextContext ) {
		if(this.state.filters !== nextState.filters){
			$('#loader').show();
			setTimeout(()=>{this.getBoatsData();},500)
			return true
		}
		else if(this.state.inventoryBoats !== nextState.inventoryBoats){ return true }
		else if(this.state.allBrands !== nextState.allBrands){ return true }
		else if(this.state.pagination.currentPage !== nextState.pagination.currentPage){return true}
		else { return false; }
	}
	
	changeKeyword(){
		let text = $('#keyword').val();
		let filters = {...this.state.filters}
		filters.searchKeyword = text;
		this.setState({filters})
	}
	
	changeCondition(event){
		let filters = {...this.state.filters}
		if(!filters.condition){
			filters.condition = []
		}
		if(event.target.checked){
			filters.condition.push(event.target.value);
			this.setState({filters})
		}
		else {
			filters.condition.pop(event.target.value);
			this.setState({filters})
		}
	}
	
	changeBrand(event){
		let filters = {...this.state.filters}
		if(!filters.selectedBrands){
			filters.selectedBrands = []
		}
		if(event.target.checked){
			filters.selectedBrands.push(event.target.value);
			this.setState({filters})
		}
		else {
			filters.selectedBrands.pop(event.target.value);
			this.setState({filters})
		}
	}
	
	changeSorting(event){
		let filters = {...this.state.filters}
		filters.sortBy = event.target.value
		this.setState({filters})
	}
	
	async getBoatsData(){
		try{
			$('#loader').show();
			this.setState({inventoryBoats:[]});
			
			let res = await userApiCall(`get_boats?currentPage=${this.state.pagination.currentPage}`,'POST',JSON.stringify(this.state.filters));
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						inventoryBoats : res.data,
						pagination : res.pagination
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	async getBoatBrands(){
		try{
			$('#loader').show();
			let res = await userApiCall(`get_all_brands`);
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({ allBrands : res.data});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	async getRangesData(){
		try{
			$('#loader').show();
			
			let res = await userApiCall(`get_ranges`);
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						lengthRange : {
							min: res.data.minLength,
							max: res.data.maxLength,
						},
						lengthRangeSelected : {
							min: res.data.minLength,
							max: res.data.maxLength,
						},
						yearRange : {
							min: res.data.minYear,
							max: res.data.maxYear,
						},
						yearRangeSelected : {
							min: res.data.minYear,
							max: res.data.maxYear,
						},
						priceRange : {
							min: res.data.minPrice,
							max: res.data.maxPrice,
						},
						priceRangeSelected : {
							min: res.data.minPrice,
							max: res.data.maxPrice,
						},
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			Swal.fire({
				title: 'Error!',
				text: 'Something gone wrong...',
				icon: 'error',
			})
			console.log(e);
		}
		finally {
			$('#loader').hide();
		}
	}
	
	renderInventoryBoats(){
		const rb = [];
		for (const [index, element] of this.state.inventoryBoats.entries()) {
			rb.push(
				<div className="col-lg-4 col-md-6 col-sm-6 col-xs-12">
					<div className="wrapper section-strt">
						<div className="image_frame">
							<a href={'boat-detail?id='+element._id}> <img src={element.boatImages.length>0?element.boatImages[0].image:'assets/images/placeholder.jpg'}/> </a>
						</div>
						<div className="boat_content">
							<h3>{element.boat_year} {element.boat_make} {element.boat_model}</h3>
							<a href={'boat-detail?id='+element._id}>{element.boat_price?'$'+element.boat_price.toLocaleString() : 'Call For Pricing'} </a>
						</div>
					</div>
				</div>
			);
		}
		return rb;
	}
	
	handlePageChange(pageNumber) {
		if(pageNumber){
			let pagination = {...this.state.pagination}
			pagination.currentPage = pageNumber
			this.setState({pagination});
		}
	}
	
	render () {
		let renderConditions = ()=>{
			let conditions = []
			this.state.allConditions.forEach(e=>{
				conditions.push(
					<p><input type="checkbox" onChange={(e)=>{this.changeCondition(e)}} name={"condition"} checked={this.state.filters.condition.indexOf(e)!= -1?true:false} value={e}/>{e}</p>
				)
			})
			return conditions;
		}
		
		let renderSorting = ()=>{
			let sorts = []
			this.state.allSorts.forEach(e=>{
				sorts.push(
					<option selected={this.state.filters.sortBy.indexOf(e)!= -1?true:false}>{e}</option>
				)
			})
			return sorts;
		}
		
		let renderBrands = ()=>{
			let brands = []
			this.state.allBrands.forEach(e=>{
				brands.push(
					<p><input type="checkbox" onChange={(e)=>{this.changeBrand(e)}} name={"brand"} checked={this.state.filters.selectedBrands.indexOf(e)!= -1?true:false} value={e}/>{e}</p>
				)
			})
			return brands;
		}
		
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'Inventory'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<section class="inventory_section inventory_section_latest section-strt">
						<div class="container">
							
							{/* Breadcrumb */}
							<BreadCrumb title={'Inventory'} navigation={this.breadcrumbNavigation}/>
							
							<div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 left_side_categories">
								<div class="row">
									<div class="col-12">
										<div class="related_posts filters_product">
											<div>
												<h3>Your Search</h3>
											</div>
											<h3>FILTER</h3>
											<div class="row filters_container">
												<div class="col-12">
													<div className="form-group">
														<input type="search" id={'keyword'} name="" placeholder="Keywords"/>
														<button className={'btn btn-info btn-xs search-btn'} onClick={this.changeKeyword.bind(this)}><i className={'fa fa-check'}></i></button>
													</div>
												</div>
												<div class="col-12">
													<div class="form-gruop">
														<h4>Condition</h4>
														{renderConditions()}
													</div>
													<div class="form-gruop">
														<h4>Brand</h4>
														{renderBrands()}
													</div>
													<div class="range-slider-container">
														<h4 className={'title'}>length</h4>
														<InputRange
															maxValue={this.state.lengthRange.max}
															minValue={this.state.lengthRange.min}
															formatLabel={value => `${value} Ft`}
															value={this.state.lengthRangeSelected}
															onChange={value => {
																this.setState({ lengthRangeSelected: value })
															}}
															onChangeComplete={value => {
																let filters = {...this.state.filters}
																filters.lengthRange.min = value.min;
																filters.lengthRange.max = value.max;
																this.setState({filters})
															}} />
													</div>
													<div className="range-slider-container">
														<h4 className={'title'}>Year</h4>
														<InputRange
															maxValue={this.state.yearRange.max}
															minValue={this.state.yearRange.min}
															value={this.state.yearRangeSelected}
															onChange={value => this.setState({ yearRangeSelected: value })}
															onChangeComplete={value => {
																let filters = {...this.state.filters}
																filters.yearRange.min = value.min;
																filters.yearRange.max = value.max;
																this.setState({filters})
															}} />
													</div>
													<div className="range-slider-container">
														<h4 className={'title'}>Price Range</h4>
														<InputRange
															maxValue={this.state.priceRange.max}
															minValue={this.state.priceRange.min}
															formatLabel={value => `${'$'+value.toLocaleString()}`}
															value={this.state.priceRangeSelected}
															onChange={value => this.setState({ priceRangeSelected: value })}
															onChangeComplete={value => {
																let filters = {...this.state.filters}
																filters.priceRange.min = value.min;
																filters.priceRange.max = value.max;
																this.setState({filters})
															}} />
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 right_side_products">
								<div class="row">
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<p class="years">
											<span class="pull-right">Sort By:
												<select class="form-control" onChange={(e)=>{this.changeSorting(e)}}>
													{renderSorting()}
												</select>
											</span>
										</p>
									</div>
								</div>
								<div class="row">
									{/* Rendering inventory boats */}
									{this.renderInventoryBoats()}
								</div>
								<div className="pagination-container">
									<Pagination
										activePage={this.state.pagination.currentPage}
										totalItemsCount={this.state.pagination.totalPages}
										pageRangeDisplayed={5}
										activeClass={'active'}
										onChange={this.handlePageChange.bind(this)}
									/>
								</div>
							</div>
						</div>
					</section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
				
			</React.Fragment>
		);
	}
}

export default Inventory;

