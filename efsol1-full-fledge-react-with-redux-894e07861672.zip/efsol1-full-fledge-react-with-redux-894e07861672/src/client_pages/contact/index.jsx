/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';
import Notifications, {notify} from 'react-notify-toast';
import { alphabets,
	alphaNumeric,
	numeric,
	validateEmail,
	validatePhoneNumber,
	validateTime,
	validateDate,
	validateFloat } from '../../utils/validator';
import $ from 'jquery';

class Contact extends React.Component {
	
	breadcrumbNavigation = [
		{
			title:'Contact Us',
			link:'#'
		}
	]
	
	submitContactRequest = ()=>{
		let body = {};
		$("form#contact-form :input").each(function(){
			let input = $(this);
			body[input.attr("name")] = input.val()
		});
		
		body['contactMethod'] = $("input[name=contact_method]:checked").val();
		
		notify.show('Great! You request has been submitted','success');
		
		$("form#contact-form :input").each(function(){
			let input = $(this);
			body[input.attr("name")] = input.val("")
		});
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'Contact'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<Notifications />
					<section className="parts_top section-strt contact">
						<div className="container">
							{/* Breadcrumb */}
							<BreadCrumb title={'Contact Us'} navigation={this.breadcrumbNavigation}/>
						</div>
					</section>
					<section className="contact-section section-strt">
						<div className="container">
							<div className="row">
								<div className="col-lg-8 col-md-6 col-sm-12 col-xs-12">
									<form id={'contact-form'}>
										<div className="row general-struct-forms">
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="First_label" htmlFor="First">First Name</label>
													<input type="text" onChange={alphabets.bind(this)} name={'firstName'} className="form-control" id="First" aria-labelledby="First_label"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="Last_label" htmlFor="Last">Last Name</label>
													<input type="text"  onChange={alphabets.bind(this)} name={'lastName'} className="form-control" id="Last" aria-labelledby="Last_label"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="Phone_label" htmlFor="Phone">Phone</label>
													<input type="text" onChange={validatePhoneNumber.bind(this)} name="phoneNo" className="form-control" id="Phone" aria-labelledby="Phone_label"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="Email_label" htmlFor="Email">Email</label>
													<input type="text" onChange={validateEmail.bind(this)} name="email" className="form-control" id="Email" aria-labelledby="Email_label"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<h2>Preferred method of contact:</h2>
													<span><input type="radio" defaultChecked name="contact_method" value={'Email'}/>Email</span>
													<span><input type="radio" name="contact_method" value={'Phone'}/>Phone</span>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="Comments_label" htmlFor="Comments">Comments</label>
													<textarea rows="8" name="comments" className="form-control" id="Comments" aria-labelledby="Comments_label"> </textarea>
												</div>
											</div>
											<div className="col-lg-8 col-md-6 col-xs-12">
												<div className="form-group pull-left">
													
													<span><input type="checkbox" name="subscribe"/> Subscribe to get the latest updates and offers by Email.</span>
												</div>
											</div>
											<div className="col-lg-4 col-md-12 col-xs-12">
												<div className="form-group pull-right">
													<input type="button" name="button" onClick={this.submitContactRequest} value="Submit"/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="">
													<img src="assets/images/map-img.jpg" className="img-responsive" alt="map-image"/>
												</div>
											</div>
										</div>
									</form>
								</div>
								<div className="col-lg-4 col-md-6 col-sm-12 col-xs-12">
									<div className="right-content">
										<p>Use this boat payment calculator to estimate monthly payments on your next new or used boat loan. Simply enter the loan amount, term and interest rate to calculate your monthly loan payments. This calculator will help you determine how much boat you can afford.
										</p>
									</div>
								</div>
							</div>
						</div>
					</section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
				
			</React.Fragment>
		);
	}
}

export default Contact;

