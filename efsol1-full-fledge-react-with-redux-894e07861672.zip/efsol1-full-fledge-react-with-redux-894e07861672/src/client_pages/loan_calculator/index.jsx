/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';


class LoanCalculator extends React.Component {
	
	breadcrumbNavigation = [
		{
			title:'Loan Calculator',
			link:'#'
		}
	]
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'Loan Calculator'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<section className="parts_top section-strt contact">
						<div className="container">
							{/* Breadcrumb */}
							<BreadCrumb title={'Loan Calculator'} navigation={this.breadcrumbNavigation}/>
						</div>
					</section>
					<section className="contact-section section-strt">
						<div className="container">
							<div className="row">
								<div className="col-lg-8 col-md-6 col-sm-12 col-xs-12">
									<form>
										<div className="row general-struct-forms">
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="vehicle_label" htmlFor="vehicle">Vehicle Price($)</label>
													<input type="text" className="form-control" id="vehicle" aria-labelledby="vehicle_label"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="Interest_label" htmlFor="Interest">Interest Rate(96)</label>
													<input type="text" className="form-control" id="Interest" aria-labelledby="Interest_label"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="Loan_label" htmlFor="Loan">Loan Period Months</label>
													<input type="text" className="form-control" id="Loan" aria-labelledby="Loan_label"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<label id="Down_label" htmlFor="Down">Down Payment ($)</label>
													<input type="text" className="form-control" id="Down" aria-labelledby="Down_label"/>
												</div>
											</div>
											<div className="col-lg-6 col-md-6 col-xs-12">
												<div className="form-group">
													<input type="button" name="button" value="Submit"/>
												</div>
											</div>
										</div>
									</form>
								</div>
								<div className="col-lg-4 col-md-6 col-sm-12 col-xs-12">
									<div className="right-content">
										<p>Use this boat payment calculator to estimate monthly payments on your next new or used boat loan. Simply enter the loan amount, term and interest rate to calculate your monthly loan payments. This calculator will help you determine how much boat you can afford.
										</p>
									</div>
								</div>
							</div>
						</div>
					</section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
				
			</React.Fragment>
		);
	}
}

export default LoanCalculator;

