/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';
import { userApiCall } from '../../utils/ajax_request';
import Swal from "sweetalert2";

class EventDetail extends React.Component {
	
	state = {
		dataLoaded : false,
		eventData : {},
		relatedEvents : []
	}
	
	breadcrumbNavigation = [
		{
			title:'Events',
			link:'news_events'
		},
		{
			title:'Event Detail',
			link:'#'
		}
	]
	
	async componentWillMount () {
		if(!this.state.dataLoaded){
			const params = new URL(window.location.href).searchParams;
			const id = params.get('id')
			this.getEventById(id)
		}
	}
	
	async getEventById(id){
		try{
			let res = await userApiCall('get_event_by_id?id='+id);
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						dataLoaded : true,
						eventData : res.data
					});
					this.getRelatedEvents();
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			console.log(e);
		}
	}
	
	async getRelatedEvents(){
		try{
			let res = await userApiCall('get_latest_news?count=3');
			if (!res) {
				Swal.fire({
					title: 'Error!',
					text: 'Something went wrong..',
					icon: 'error',
				})
				return false;
			}
			if ( res.hasOwnProperty('status') ) {
				if ( res.status == 200 && res.hasOwnProperty('data') ) {
					this.setState({
						relatedEvents : res.data
					});
				} else if ( res.status == 400 ) {
					Swal.fire({
						title: 'Error!',
						text: res.message,
						icon: 'error',
					})
				}
			}
		}
		catch ( e ){
			console.log(e);
		}
	}
	
	renderSideEvents(){
		const events = [];
		for ( const [index, element] of this.state.relatedEvents.entries() ) {
			if(element._id != this.state.eventData._id){
				events.push(
					<div className="col-12">
						<div className="form-group">
							<div className="event-tile"><h2>{element.eventTitle}</h2></div>
							<div className="event-date"><span>{element.eventMonth +' '+  element.eventDate +' '+ element.eventYear}</span></div>
							<p>{element.eventDescription}</p>
							<a href={"event_detail?id="+element._id}>Read more >></a>
						</div>
					</div>
				);
			}
		}
		return events;
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'Event detail'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<section class="parts_top section-strt ">
						<div class="container">
							{/* Breadcrumb */}
							<BreadCrumb title={''} navigation={this.breadcrumbNavigation}/>
						</div>
					</section>
					
					{!this.state.dataLoaded?
						<React.Fragment>
							<h1>Loading..</h1>
						</React.Fragment>
						:
						<React.Fragment>
							<section className=" resource_article_section product-detail_section article-detail-sec section-strt">
							<div className="container">
								<div className="row">
									<div className="col-lg-8 col-md-8 col-sm-12 col-xs-12">
										<p className="years"><span><a href="#">{this.state.eventData.eventTitle}</a></span></p>
										<div className="row">
											<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
												<div className='event_wrapper'>
													<div className="event_img_frame">
														<img src={this.state.eventData.eventImages.length>0?this.state.eventData.eventImages[0]:'assets/images/placeholder.jpg'} className="img-fluid"/>
													</div>
													<div className="event_content section-strt">
														<div className="row">
															<div className="col-md-12 col-lg-12 col-sm-12 col-xs-12 col-12">
																<div className="article_detail section-strt">
																	<div className="section-strt">
																		<div className="event-tile pull-left"><h2>Posted {this.state.eventData.eventMonth +' '+  this.state.eventData.eventDate +' '+ this.state.eventData.eventYear}</h2></div>
																		<div className="event-date pull-right">
																			<span><a href="#"><i hidden="hidden">Facebook</i><i className="fa fa-facebook-f"></i></a></span>
																			<span><a href="#"><i hidden="hidden">Instagram</i><i className="fa fa-instagram"></i></a></span>
																			<span><a href="#"><i hidden="hidden">Youtube</i><i className="fa fa-youtube"></i></a></span>
																		</div>
																	</div>
																	<div className="art-description">
																		<ul>
																			<li><strong>Location: </strong> <strong>{this.state.eventData.location_name}</strong></li>
																		</ul>
																		<p>{this.state.eventData.eventDescription}</p>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div className="col-lg-4 col-md-4 col-sm-12 col-12">
										<div className="row">
											<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
												<div className='event_wrapper'>
													<div className="event_content event_content_right ">
														<div className="contact_wrapper">
															<form>
																<div className="row">
																	{this.renderSideEvents()}
																</div>
															</form>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</section>
						</React.Fragment>
					}
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
			</React.Fragment>
		);
	}
}

export default EventDetail;

