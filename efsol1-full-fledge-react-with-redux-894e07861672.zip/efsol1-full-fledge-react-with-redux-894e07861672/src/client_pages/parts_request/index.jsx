/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-18
 */
import React from 'react';
import './style.css';
import PageHeader from '../../components/page-header';
import PageFooter from '../../components/page-footer';
import ChangeTitle from '../../components/change_page_title';
import BreadCrumb from '../../components/bread-crumb';
import $ from 'jquery'
import Notifications, {notify} from 'react-notify-toast';
import { alphabets,
	alphaNumeric,
	numeric,
	validateEmail,
	validatePhoneNumber,
	validateTime,
	validateDate,
	validateFloat } from '../../utils/validator';

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";


class PartsRequest extends React.Component {
	
	breadcrumbNavigation = [
		{
			title:'Parts Request',
			link:'#'
		}
	]
	
	state = {
		shippingAddressSame : false,
		preferredDate: new Date()
	}
	
	toggleShippingAddress = ()=>{
		this.setState({shippingAddressSame: $('#shippingAddress').prop('checked')})
	}
	
	handleDateChange = (date)=>{
		this.setState({preferredDate:date})
	}
	
	submitPartsRequest = ()=>{
		let body = {};
		$("form#parts-request-form :input").each(function(){
			let input = $(this);
			body[input.attr("name")] = input.val()
		});
		
		body['preferred_date'] = this.state.preferredDate;
		body['parts'] = $("input[name=parts]:checked").val();
		
		notify.show('Great! You request has been submitted','success');
		
		$("form#parts-request-form :input").each(function(){
			let input = $(this);
			body[input.attr("name")] = input.val("")
		});
	}
	
	render () {
		return (
			/*Content Area*/
			<React.Fragment>
				
				<ChangeTitle title={'Parts Request'}/>
				
				{/*Page Header*/}
				<PageHeader/>
				
				{/*Page specific content*/}
				<main>
					<Notifications />
					<section className="parts_top section-strt contact">
						<div className="container">
							{/* Breadcrumb */}
							<BreadCrumb
								title={'Parts Request'}
								description={'Wolf Watersports stocks a wide variety of inboard parts. We pride ourselves on having a full inventory ready to service your boats needs at any moment. If you require a special part, do not hesitate to call on one of our industry professionals. We are happy to get you any part you may require.'}
								navigation={this.breadcrumbNavigation}/>
						</div>
					</section>
					<section className="contact-section section-strt">
						<div className="container">
							<form id={'parts-request-form'}>
								<div className="row plr">
									<div className="col-xs-12 text-center request-form">
										<h2>Reguest form</h2>
									</div>
									<div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
										<div className="row general-struct-forms">
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<h2>Contact Info:</h2>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="First_label" htmlFor="First">First Name</label>
													<input type="text" onChange={alphabets.bind(this)} id="first_name" name="firstName" aria-labelledby="FirstNameLabel"
														className="form-control" placeholder="First Name*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Last_label" htmlFor="Last">Last Name</label>
													<input type="text" onChange={alphabets.bind(this)} id="last_name" name="lastName" aria-labelledby="lastNameLabel"
														className="form-control" placeholder="Last Name*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Phone_label" htmlFor="Phone">Phone</label>
													<input type="text" onChange={validatePhoneNumber.bind(this)} id="phone" name="phoneNo" aria-labelledby="PhoneLabel"
														className="form-control" placeholder="Phone*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Email_label" htmlFor="Email">Email</label>
													<input type="email" onChange={validateEmail.bind(this)} name="email" className="form-control" aria-labelledby="EmailLabel" id="email" placeholder="Email*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<h2>Billing Address:</h2>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Address_label" htmlFor="Address">Billing Phone*</label>
													<input onChange={alphaNumeric.bind(this)} type="text" id="billing_phone" aria-labelledby="BillingPhoneLabel" name="phoneNo"
														className="form-control" placeholder="phone*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="City_label" htmlFor="City">billing email*</label>
													<input type="email" id={'billing_email'} onChange={validateEmail.bind(this)} name="billing_email" aria-labelledby="billingEmailLabel"
														className="form-control" placeholder="Email*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="State_label" htmlFor="State">preferred Date/Time*</label>
													<br/>
													<DatePicker
														selected={this.state.preferredDate}
														onChange={this.handleDateChange}
														showTimeSelect
														dateFormat="Pp"
													/>
												</div>
											</div>
											<div className="col-12">
												<div className="form-group clearfix">
													<label id="CheckBoxLabel" htmlFor="CheckBox" hidden>Check box</label>
													<span>
														<input id='shippingAddress' className="check_this_box" onChange={this.toggleShippingAddress.bind(this)} aria-labelledby="CheckBoxLabel" type="checkbox" name=""/> Shipping address is different from billing address
													</span>
												</div>
											</div>
											<div className="col-12">
												<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
													<div className="contact_wrapper shipping_address_form" style={!this.state.shippingAddressSame?{display:'none'}:{display: 'block'}}>
														<div className="row">
															<div className="col-12">
																<div className="form-group clearfix">
																	<label id="AddressLabel" htmlFor="Address" hidden>Address</label>
																	<input id="shipping_address" type="text" name="shipping_address" aria-labelledby="AddressLabel" className="form-control" placeholder="Address"/>
																</div>
															</div>
															<div className="col-12">
																<div className="form-group clearfix">
																	<label id="CityLabel" htmlFor="City" hidden>City</label>
																	<input id="shipping_city" name="shipping_city" className="form-control" aria-labelledby="AddressLabel" placeholder="City"/>
																</div>
															</div>
															<div className="col-12">
																<div className="form-group clearfix">
																	<label id="ZipCodeLabel" htmlFor="ZipCode" hidden>Zip Code</label>
																	<input id="shipping_zipcode" name="shipping_zipcode" aria-labelledby="ZipCodeLabel" className="form-control" placeholder="Zip Code"/>
																</div>
															</div>
															<div className="col-12">
																<div className="form-group clearfix">
																	<label id="CountryLabel" htmlFor="Country" hidden>Country</label>
																	<input id="shipping_country" name="shipping_country" aria-labelledby="CountryLabel" className="form-control" placeholder="Country"/>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
										<div className="row general-struct-forms">
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<h2>I am requesting:</h2>
													<label id="BoatsPartLabel" htmlFor="BoatsPart" hidden> Boats Part</label>
													<span><input aria-labelledby="BoatsPartLabel" type="radio" name="parts"
														value="Boats Parts" defaultChecked required/>Boats Parts</span>
													<label id="MotorPartsLabel" htmlFor="MotorParts" hidden> Motor Parts</label>
													<span><input type="radio" aria-labelledby="MotorPartsLabel" name="parts"
														value="Motor Parts" required/>Motor Parts</span>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Year_label" htmlFor="Year">Year*</label>
													<input type="number" onChange={numeric.bind(this)} aria-labelledby="YearLabel" id="boat_year" name="year"
														className="form-control" placeholder="Year*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Make_label" htmlFor="Make">Make*</label>
													<input type="text" onChange={alphaNumeric.bind(this)} id="boat_make" aria-labelledby="MakeLabel" name="make"
														className="form-control" placeholder="Make*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Model_label" htmlFor="Model">Model*</label>
													<input type="text" onChange={alphaNumeric.bind(this)} id="boat_model" aria-labelledby="ModelLabel" name="model"
														className="form-control" placeholder="Model*" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Hull_label" htmlFor="Hull">Hull ID</label>
													<input type="text"onChange={alphaNumeric.bind(this)} id="boat_hullid" aria-labelledby="boat_hullidLabel" name="hullId"
														className="form-control" placeholder="Hull ID" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Part_label" htmlFor="Part">Part Number</label>
													<input type="text" id="part_number" name="hours" aria-labelledby="part_numberLabel" onChange={alphaNumeric.bind(this)}
														className="form-control" placeholder="Part Number" required/>
												</div>
											</div>
											<div className="col-lg-12 col-md-12 col-xs-12">
												<div className="form-group">
													<label id="Description_label" htmlFor="Description">Part Description</label>
													<textarea rows="5" className="form-control" id="part_description" aria-labelledby="part_descriptionLabel"
														onChange={alphaNumeric.bind(this)} name="description" placeholder="Part description" required/>
												</div>
											</div>
										</div>
									</div>
									<div className="col-lg-12 col-md-12 col-xs-12 general-struct-forms">
										<div className="form-group">
											<input type="button" name="button" id="part_btn" onClick={this.submitPartsRequest} value="Add Parts"/>
										</div>
									</div>
								</div>
							</form>
						</div>
					</section>
				</main>
				
				{/*Page Footer*/}
				<PageFooter/>
				
			</React.Fragment>
		);
	}
}

export default PartsRequest;

