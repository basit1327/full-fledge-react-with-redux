'use strict';

module.exports = {
    environment: "LOCAL",
    hostname: 'localhost',
    serverPort : 3006,
    mongoConnectionString:'mongodb://perfectmongo:polkiujhytgf@18.191.218.9:27017/wolf',
    jwtSecret:'29dsa@#$cw444'
};
