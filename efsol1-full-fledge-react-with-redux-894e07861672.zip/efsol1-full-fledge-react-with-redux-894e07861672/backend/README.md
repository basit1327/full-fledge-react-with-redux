# c3
## A simple NodeJS Application
### Includes JWT authentication, MySQL database, API's and more
