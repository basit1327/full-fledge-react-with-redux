'use strict';

const publicApiController = require('./public'),
    adminApiController = require('./admin'),
    loginRoute = require('./login'),
    authService = require('../services/auth'),
    bodyParser = require('body-parser')

function init(server) {

    // supporting every casing in query parameters
    server.use(function (req, res, next) {
        for (var key in req.query) {
            req.query[key.toLowerCase()] = req.query[key];
        }
        for (var key in req.body) {
            req.body[key.toLowerCase()] = req.body[key];
        }
        next();
    });
    
    // parse application/json
    server.use(bodyParser.json())

    server.use('/', function (req, res, next) {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', "Origin, X-Requested-With, Content-Type, Authorization");
        next();
    });

    server.get('/', function (req, res) {
        res.send('|--- WOLF WATER-SPORTS SERVER IS LIVE ---|')
    });

    server.use('/public',publicApiController);
    server.use('/admin',authService.authenticateAdminSession,adminApiController);
    server.use('/auth',loginRoute);
}

module.exports = {
    init: init
};
