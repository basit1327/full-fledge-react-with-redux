'use strict';

const
	express = require('express'),
	adminApiController = require('../../controllers/admin');

let router = express.Router();

router.use('/', adminApiController);

module.exports = router;
