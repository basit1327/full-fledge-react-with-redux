/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-11
 */


const config = require('../../configs'),
	MongoClient = require('mongodb').MongoClient,
	mongodbUri = require('mongodb-uri');

let db;

MongoClient.connect(config.mongoConnectionString, {}, (err, client) => {
	if(err){
		console.log(colors.red('Error connecting to MongoDB: ' + err));
		process.exit(2);
	}
	
	const dbUriObj = mongodbUri.parse(config.mongoConnectionString);
	
	// if in testing, set the testing DB
	if(process.env.NODE_ENV === 'test'){
		db = client.db(dbUriObj+'_test');
	}else{
		db = client.db(dbUriObj.database);
	}
	
	// setup the collections
	db.users = db.collection('users');
	db.users_session= db.collection('users_session');
	db.products = db.collection('products');
	db.orders = db.collection('orders');
	db.pages = db.collection('pages');
	db.menu = db.collection('menu');
	db.customers = db.collection('customers');
	db.boats = db.collection('boats');
	db.email_template = db.collection('email_template');
	db.email_setting = db.collection('email_setting');
	db.email_notifications = db.collection('email_notifications');
	db.category = db.collection('category');
	db.saleforce_attachment = db.collection('saleforce_attachment');
	db.value_trade = db.collection('value_trade');
	db.boat_test_drive = db.collection('boat_test_drive');
	db.boatSales = db.collection('boatSales');
	db.sale_attach = db.collection('sale_attach');
	db.events = db.collection('events');
});

function getDbConnection(){
	return db;
}

module.exports = {
	getDbConnection
}
