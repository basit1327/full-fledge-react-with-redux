'use strict';
const _ = require('lodash'),
	activeSessionStatus = 1,
	config = require('../../../configs/local'),
	jwt = require('jsonwebtoken'),
	mongoCon = require('../../data_access/mongo'),
	ObjectId = require('mongodb').ObjectID;

async function authenticateAdminSession(req,res,next){
	let authToken = req.headers.authorization;
	let sessionHash = null;
	if ( !authToken ){
		res.send({status:440,message:'No authorization token with api request'});
		res.end();
		return;
	}
	
	let con = mongoCon.getDbConnection();
	try {
		let decodedToken = jwt.verify(authToken, config.jwtSecret);
		sessionHash = decodedToken.sessionHash;
		if ( !sessionHash ){
			res.send({status:440,message:'Could not authenticate, Invalid auth token'});
			res.end();
			return;
		}
		
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let response = await con.users_session.findOne({sessionHash:sessionHash,status:activeSessionStatus})
		if ( response._id ) {
			req.sessionId = sessionHash
			next()
		} else {
			res.send({status:440,message:'Your session has been expired'});
			res.end();
		}
	}
	catch (e) {
		console.log('Exception: ', e);
		res.send({status:440,message:'Something went wrong while authenticating session'});
		res.end();
	}
}

module.exports = {
	authenticateAdminSession
};
