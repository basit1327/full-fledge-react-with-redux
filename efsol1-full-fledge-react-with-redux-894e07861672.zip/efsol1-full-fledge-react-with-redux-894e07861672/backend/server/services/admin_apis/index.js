/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-08
 */

'use strict';
const _ = require('lodash'),
	{invalidQueryResult,failedToGetDatabaseConnection} = require('../../../configs/res_codes'),
	mongoCon = require('../../data_access/mongo'),
	ObjectId = require('mongodb').ObjectID;

/*============================================================================*/
/*================================= BOATS ====================================*/
async function getBoats(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let getKeywordFilter = ()=>{
			if(req.body.searchKeyword){
				return {$regex: `(?i)${req.body.searchKeyword}`}
			}
			else return {$exists: true}
		}
		
		let currentPage = Number(req.query.currentPage) || 1;
		let filters = {
			boatTitle: getKeywordFilter(),
		}
		
		
		let getBoats = con.boats.find(filters)
			.project({boatTitle:1})
			.skip((currentPage-1)*10)
			.limit(10)
			.toArray();
		
		let getCount = con.boats.count(filters);
		let data = await Promise.all([getBoats,getCount]);
		if(data[0].length>0){
			res.send({
				status:200,
				data:data[0],
				pagination:{
					currentPage:currentPage,
					totalPages:data[1]
				}
			});
		}
		else {
			res.send({
				status:400,
				message:'No record found...'
			});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}
/*================================= BOATS END ================================*/





/*============================================================================*/
/*================================= PRODUCTS =================================*/
async function getProducts(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let getKeywordFilter = ()=>{
			if(req.body.searchKeyword){
				return {$regex: `(?i)${req.body.searchKeyword}`}
			}
			else return {$exists: true}
		}
		
		let currentPage = Number(req.query.currentPage) || 1;
		let filters = {
			productTitle: getKeywordFilter(),
		}
		
		
		let getProducts = con.products.find(filters)
			.project({productTitle:1})
			.skip((currentPage-1)*10)
			.limit(10)
			.toArray();
		
		let getCount = con.products.count(filters);
		let data = await Promise.all([getProducts,getCount]);
		if(data[0].length>0){
			res.send({
				status:200,
				data:data[0],
				pagination:{
					currentPage:currentPage,
					totalPages:data[1]
				}
			});
		}
		else {
			res.send({
				status:400,
				message:'No record found...'
			});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}
/*=============================== PRODUCTS END ===============================*/





/*============================================================================*/
/*================================= EVENTS ===================================*/
async function getEvents(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let getKeywordFilter = ()=>{
			if(req.body.searchKeyword){
				return {$regex: `(?i)${req.body.searchKeyword}`}
			}
			else return {$exists: true}
		}
		
		let currentPage = Number(req.query.currentPage) || 1;
		let filters = {
			eventTitle: getKeywordFilter(),
		}
		
		
		let getEvents = con.events.find(filters)
			.project({eventTitle:1})
			.skip((currentPage-1)*10)
			.limit(10)
			.toArray();
		
		let getCount = con.events.count(filters);
		let data = await Promise.all([getEvents,getCount]);
		if(data[0].length>0){
			res.send({
				status:200,
				data:data[0],
				pagination:{
					currentPage:currentPage,
					totalPages:data[1]
				}
			});
		}
		else {
			res.send({
				status:400,
				message:'No record found...'
			});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}
/*================================= EVENS END ================================*/





/*============================================================================*/
/*================================= USERS ====================================*/
async function getUsers(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let getUsers = con.users.find({}).project({userPassword:0}).toArray();
		
		let data = await Promise.all([getUsers]);
		if(data[0].length>0){
			res.send({
				status:200,
				data:data[0]
			});
		}
		else {
			res.send({
				status:400,
				message:'No record found...'
			});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}
/*================================= USERS END ================================*/





/*============================================================================*/
/*================================= EMAIL ====================================*/
async function getEmailTemplates(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let getEmailTemplates = con.email_template.find({}).project({template_slug:1,template_name:1}).toArray();
		
		let data = await Promise.all([getEmailTemplates]);
		if(data[0].length>0){
			res.send({
				status:200,
				data:data[0]
			});
		}
		else {
			res.send({
				status:400,
				message:'No record found...'
			});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function createNewEmailTemplate(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		if(!req.body.slug || !req.body.name){
			res.send({status:400,message:'Slug/Name should not empty'});
			return
		}
		let templateCountWithSameSlug = await con.email_template.count({template_slug:req.body.slug})
		if(templateCountWithSameSlug==0){
			let insertResponse = await con.email_template.insertOne({template_slug:req.body.slug,template_name:req.body.name});
			if(insertResponse.insertedId){
				res.send({
					status:200,
					message:'New template created.',
					data:{
						_id:insertResponse.insertedId,
						template_slug:req.body.slug,
						template_name:req.body.name,
					}
				})
			}
		}
		else {
			res.send({status:400,message:'Template with same slug already exist'});
			return
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function deleteEmailTemplateById(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		if(!req.query.id){
			res.send({status:400,message:'Invalid request'});
			return
		}
		let deleteResponse = await con.email_template.deleteOne({_id:ObjectId(req.query.id)});
		if(deleteResponse.deletedCount>0){
			res.send({status:200,message:'Template deleted',id:req.query.id});
			return
		}
		else {
			res.send({status:400,message:'No record deleted...'});
			return
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getEmailSetting(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		let data = await con.email_setting.find().toArray();
		if(data.length>0){
			let JSData = {};
			data.forEach(e=>{
				JSData[e.key] = e.val
			});
			res.send({status:200,message:'Template setting',data:JSData});
			return
		}
		else {
			res.send({status:400,message:'No record for email setting'});
			return
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function saveEmailSetting(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		if(!req.body.setting){
			res.send({status:400,message:'Invalid request'});
			return
		}
		let promises = []
		for(let s in req.body.setting){
			promises.push(con.email_setting.updateOne({key:s},{$set:{val:req.body.setting[s]}}))
		}
		await Promise.all(promises);
		res.send({status:200,message:'Setting update'});
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getEmailTemplatesBySlug(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		if(!req.query.slug){
			res.send({status:400,message:'Invalid request'});
			return
		}
		
		let template = await con.email_template.findOne({template_slug:req.query.slug});
		if(template.hasOwnProperty('_id')){
			res.send({status:200,message:'Template data',data:template});
		}
		else {
			res.send({status:400,message:'No record found'});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function updateEmailTemplatesBySlug(req,res){
	let con = mongoCon.getDbConnection();
	try{
		let {template_slug,template_name,email_to,bcc,from,from_email,email_subject,content} = req.body;
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		if(!template_slug){
			res.send({status:400,message:'Invalid request'});
			return
		}
		
		let updateResult = await con.email_template.updateOne({template_slug},{
			$set:{
				template_name,
				email_to,
				bcc,
				from,
				from_email,
				email_subject,
				content
			}
		});
		console.log(updateResult.matchedCount);
		if(updateResult.matchedCount>0){
			res.send({status:200,message:'Record updated successfully'});
		}
		else {
			res.send({status:400,message:'No matching record found'});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}
/*================================= EMAIL END ================================*/

module.exports = {
	getBoats,
	getProducts,
	getEvents,
	getUsers,
	getEmailTemplates,
	createNewEmailTemplate,
	deleteEmailTemplateById,
	getEmailSetting,
	saveEmailSetting,
	getEmailTemplatesBySlug,
	updateEmailTemplatesBySlug
};
