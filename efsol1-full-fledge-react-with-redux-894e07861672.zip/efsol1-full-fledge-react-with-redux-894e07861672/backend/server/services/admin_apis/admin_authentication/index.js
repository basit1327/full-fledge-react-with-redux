'use strict';
const _ = require('lodash'),
	config = require('../../../../configs/local'),
	md5 = require('md5'),
	jwt = require('jsonwebtoken'),
	deletedSessionStatus = 0,
	activeSessionStatus = 1,
	{failedToGetDatabaseConnection} = require('../../../../configs/res_codes'),
	mongoCon = require('../../../data_access/mongo'),
	ObjectId = require('mongodb').ObjectID;


async function adminLogin (req,res){
	let con = mongoCon.getDbConnection();
	try {
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let {email,password} = req.body;
		if ( !email || !password ) {
			res.send({status:400,message:'Invalid email or password'});
			return;
		}
		
		let response = await con.users.findOne({userEmail:email,userPassword:md5(password.toString())});
		if(response && response.hasOwnProperty('_id')){
			let hash = md5(new Date()+ Math.random());
			let token = jwt.sign({ sessionHash: hash }, config.jwtSecret);
			let data = {
				name:response.usersName,
				isAdmin:response.isAdmin,
				token
			}
			res.send({
				status:200,
				message:'logged in successfully',
				data
			});
			saveNewAdminSession(hash,response._id);
		}
		else {
			res.send({status:400,message:'No record found'});
		}
	}
	catch (e) {
		res.send({status: 400, message: 'something went wrong while trying to login'});
		console.log('Exception: ', e);
	}
}

async function adminLogOut (req,res){
	if ( req.sessionId ){
		res.send({status:200,message:'logged out successfully'});
		deleteAdminSession(req.sessionId);
	}
	else {
		res.send({status:400,message:'Failed to logout, Authentication header not present'});
	}
}

async function updateAccount (req,res){
	let connection;
	try {
		let {firstName,lastName,password} = req.body;
		if ( !password && !firstName && !lastName ) {
			res.send({status:400,message:'Invalid request, you must provide at least one to update (first name, last name, password)'});
			return;
		}
		
		connection = await new DbConnection().getConnection();
		if ( connection ) {
			
			let updateQuerySub = '';
			let updateQueryParam = [];
			if ( firstName ){updateQuerySub+= ' first_name=? , '; updateQueryParam.push(firstName)}
			if ( lastName ){updateQuerySub+= ' last_name=? , '; updateQueryParam.push(lastName)}
			if ( password ){updateQuerySub+= ' password=? , '; updateQueryParam.push(md5(password))}
			
			// removing comma from last
			updateQuerySub = updateQuerySub.substr(0,updateQuerySub.length-2);
			
			
			let dbRes = await connection.query(`UPDATE admin_accounts SET ${updateQuerySub}
			WHERE id = ?`,[...updateQueryParam,req.userId]);
			if ( _.has(dbRes,'affectedRows') ){
				res.send({status:200,message:'Account details updated'});
			} else {
				throw 'something went wrong while updating user details'
			}
		} else {
			res.send({status: 400, message: failedToGetDatabaseConnection.description});
		}
	}
	catch (e) {
		res.send({status: 400, message: 'something went wrong while trying to update details'});
		console.log('Exception: ', e);
	}
	finally {
		if ( connection ) {
			connection.release();
		}
	}
}


/* Saving and deleting session */
async function saveNewAdminSession(sessionHash,userId){
	let con = mongoCon.getDbConnection();
	try {
		if(!con){
			throw 'Failed to save admin session, con is undefined';
		}
		let response = await con.users_session.insertOne({
			sessionHash,
			userId:ObjectId(userId),
			status:activeSessionStatus,
			created_at:new Date()
		});
		if(!response.insertedCount || response.insertedCount==0){
			throw 'Session not save insertedCount is '+response.insertedCount;
		}
	}
	catch (e) {
		console.log('Exception: ', e);
	}
}

async function deleteAdminSession(sessionHash){
	let con = mongoCon.getDbConnection();
	try {
		if(!con){
			throw 'Failed to update admin session, con is undefined';
		}
		let response = await con.users_session.updateOne({sessionHash},{$set:{status:deletedSessionStatus}});
		if(!response.matchedCount){
			throw 'session status not updated matchedCount:'+response.matchedCount
		}
	}
	catch (e) {
		console.log('Exception: ', e);
	}
}


module.exports = {
	adminLogin,
	adminLogOut,
	updateAccount
};
