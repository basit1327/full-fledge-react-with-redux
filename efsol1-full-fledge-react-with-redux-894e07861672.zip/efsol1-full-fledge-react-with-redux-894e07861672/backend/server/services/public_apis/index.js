/**
 * @author Basit Raza <razabasit88@gmail.com>
 * @link http://be.net/basit_raza Author Website
 * @since 2021-01-08
 */

'use strict';
const _ = require('lodash'),
	{invalidQueryResult,failedToGetDatabaseConnection} = require('../../../configs/res_codes'),
	mongoCon = require('../../data_access/mongo'),
	ObjectId = require('mongodb').ObjectID;


async function getHeaderMenu(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		let headerMenu = await con.menu.findOne({location:'header_menu'});
		if(_.has(headerMenu,'items')){
			//TODO for testing
			headerMenu.items = [
				{
					title:'home',
					open_in:'redirect',
					link:'/',
					children:[]
				},
				{
					title:'inventory',
					open_in:'redirect',
					link:'#',
					children:[
						{
							title:'New Boats',
							open_in:'redirect',
							link:'inventory',
						},
						{
							title:'Pre-Owned Boats',
							open_in:'redirect',
							link:'#',
						},
						{
							title:'Value Your Trade',
							open_in:'redirect',
							link:'article_detail',
						},
						{
							title:'Loan Calculator',
							open_in:'redirect',
							link:'loan_calculator',
						},
					]
				},
				{
					title:'service',
					open_in:'redirect',
					link:'/service',
					children:[]
				},
				{
					title:'parts',
					open_in:'redirect',
					link:'parts_request',
					children:[]
				},
				{
					title:'events',
					open_in:'redirect',
					link:'news_events',
					children:[]
				},
				{
					title:'contact',
					open_in:'redirect',
					link:'#',
					children:[
						{
							title:'Contact',
							open_in:'redirect',
							link:'contact',
						},
						{
							title:'About WolfWaterSports',
							open_in:'redirect',
							link:'',
						}
					]
				},
			]
			
			res.send({
				status:200,
				data:headerMenu.items
			});
		}
		else {
			res.send({
				status:200,
				message:'failed to get header menu'
			});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getFeaturedBoats(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		let count = req.query.count || 2;
		if(isNaN(Number(count)) || !req.query.count || Number(req.query.count)>50){
			count = 2;
		}
		let featuredBoats = await con.boats.find({"is_featured": "Yes"}).limit(Number(count)).toArray();
		res.send({
			status:200,
			data:featuredBoats
		});
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getLatestNews(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		let count = req.query.count || 2;
		let skip = Number(req.query.skip) || 0;
		if(isNaN(Number(count)) || !req.query.count || Number(req.query.count)>50){
			count = 2;
		}
		let events = await con.events.find().skip(skip*10).limit(Number(count)).toArray();
		res.send({
			status:200,
			data:events
		});
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getEvents(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		let skip = Number(req.query.skip) || 0;
		let getDistinctYear = [{
			$match: {
				eventYear: {
					$exists: true
				}
			}
		}, {
			$group: {
				_id: {
					eventYear: "$eventYear"
				}
			}
		}, {
			$project: {
				eventYear: "$_id.eventYear"
			}
		}, {
			$sort: {
				_id: -1
			}
		}, {
			$limit: 100
		}]
		let years = [];
		
		Promise.all([
				con.events.aggregate(getDistinctYear).toArray(),
				con.events.find({}).project({eventYear:1,eventMonth:1}).toArray(),
				con.events.find({}).skip(skip*10).toArray(),
			])
			.then(([_years,_month,_data]) => {
				_years.forEach(y=>{
					years.push({
						year:y.eventYear,
						data:[]
					})
				})
				
				_month.forEach(m=>{
					let correspondingYear = years.filter(e=>e.year==m.eventYear)[0]
					correspondingYear.data.push({
						month:m.eventMonth,
						data:[]
					})
				})
				
				_data.forEach(d=>{
					let correspondingYear = years.filter(e=>e.year==d.eventYear)[0]
					let correspondingMonth = correspondingYear.data.filter(e=>e.month==d.eventMonth)[0]
					correspondingMonth.data.push(d)
				})
				
				let data = years;
				res.send({status:200,message:'Events record',data})
			})
		
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getEventById(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		let id = req.query.id;
		if(!id){
			res.send({
				status:400,
				message:'Invalid request!'
			});
		}
		else {
			let data = await con.events.find({_id:ObjectId(id)}).toArray()
			if(data.length>0){
				res.send({
					status:200,
					data:data[0]
				});
			}
			else {
				res.send({
					status:400,
					message:'No record found...'
				});
			}
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getBoatById(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let id = req.query.id;
		if(!id){
			res.send({
				status:400,
				message:'Invalid request!'
			});
		}
		else {
			let data = await con.boats.find({_id:ObjectId(id)}).toArray()
			if(data.length>0){
				res.send({
					status:200,
					data:data[0]
				});
			}
			else {
				res.send({
					status:400,
					message:'No record found...'
				});
			}
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getAllBrands(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		let data = await con.boats.distinct('boat_brand')
		res.send({status:200,message:'All brands',data})
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getRanges(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		let data = await con.boats.aggregate([
			{"$match":{boatPrice:{$ne:NaN}}},
			{"$match":{boat_length:{$exists: true}}},
			{"$match":{boat_year:{$exists: true}}},
			{ "$group": {
					"_id": null,
					"maxPrice": { "$max": "$boatPrice" },
					"minPrice": { "$min": "$boatPrice" },
					"maxLength": { "$max": "$boat_length" },
					"minLength": { "$min": "$boat_length" },
					"maxYear": { "$max": "$boat_year" },
					"minYear": { "$min": "$boat_year" },
				}}
		]).toArray()
		if(data[0]){
			res.send({status:200,message:'All brands',data:data[0]})
		}
		else {
			res.send({status:400,message:'Failed to load ranges..'})
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}

async function getBoats(req,res){
	let con = mongoCon.getDbConnection();
	try{
		if(!con){
			res.send({status:400,message:failedToGetDatabaseConnection});
			return
		}
		
		let getConditionFilter = ()=>{
			if(req.body.condition && req.body.condition.length>0){
				return {$in: req.body.condition}
			}
			else return {$exists: true}
		}
		
		let getBrandFilter = ()=>{
			if(req.body.selectedBrands && req.body.selectedBrands.length>0){
				return {$in: req.body.selectedBrands}
			}
			else return {$exists: true}
		}
		
		let getSortingFilter = ()=>{
			if(req.body.sortBy && req.body.sortBy==='Ascending'){
				return {_id:-1}
			}
			else return {_id:1}
		}
		
		let getKeywordFilter = ()=>{
			if(req.body.searchKeyword){
				return {$regex: `(?i)${req.body.searchKeyword}`}
			}
			else return {$exists: true}
		}
		
		
		let currentPage = Number(req.query.currentPage) || 1;
		let filters = {
			boatTitle: getKeywordFilter(),
			boat_condition: getConditionFilter(),
			boat_brand: getBrandFilter(),
			boat_length: {
				$gte: Number(req.body.lengthRange.min) || 0,
				$lte: Number(req.body.lengthRange.max) || 100
			},
			boat_year: {
				$gte: Number(req.body.yearRange.min) || 1999,
				$lte: Number(req.body.yearRange.max) || 2050
			},
			boatPrice: {
				$gte: Number(req.body.priceRange.min) || 0,
				$lte: Number(req.body.priceRange.max) || 100000000
			},
		}
		
		let getBoats = con.boats.find(filters)
			.skip((currentPage-1)*10)
			.limit(10)
			.sort(getSortingFilter())
			.toArray();
		
		let getCount = con.boats.count(filters);
		let data = await Promise.all([getBoats,getCount]);
		if(data[0].length>0){
			res.send({
				status:200,
				data:data[0],
				pagination:{
					currentPage:currentPage,
					totalPages:data[1]
				}
			});
		}
		else {
			res.send({
				status:400,
				message:'No record found...'
			});
		}
	}
	catch (e){
		console.log(e);
		res.send({status:400,message:'something went wrong...'})
	}
}


module.exports = {
	getHeaderMenu,
	getFeaturedBoats,
	getLatestNews,
	getEvents,
	getEventById,
	getBoatById,
	getAllBrands,
	getRanges,
	getBoats,
};
