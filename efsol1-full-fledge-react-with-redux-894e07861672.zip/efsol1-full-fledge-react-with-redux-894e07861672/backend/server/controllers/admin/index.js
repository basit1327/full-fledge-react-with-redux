'use strict';

const
	express = require('express'),
	adminApiService = require('../../services/admin_apis'),
	adminAuthService = require('../../services/admin_apis/admin_authentication')

let router = express.Router();

router.get('/logout',adminAuthService.adminLogOut);
router.post('/get_boats',adminApiService.getBoats);
router.post('/get_products', adminApiService.getProducts);
router.post('/get_events', adminApiService.getEvents);
router.get('/get_users', adminApiService.getUsers);
router.get('/get_email_templates', adminApiService.getEmailTemplates);
router.post('/create_email_template', adminApiService.createNewEmailTemplate);
router.get('/delete_email_template', adminApiService.deleteEmailTemplateById);
router.get('/get_email_setting', adminApiService.getEmailSetting);
router.post('/save_email_setting', adminApiService.saveEmailSetting);
router.get('/get_email_template_data', adminApiService.getEmailTemplatesBySlug);
router.post('/update_email_template_data', adminApiService.updateEmailTemplatesBySlug);

module.exports = router;
