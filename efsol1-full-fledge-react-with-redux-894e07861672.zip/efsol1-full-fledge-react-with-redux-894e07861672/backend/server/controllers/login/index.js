'use strict';

const
	express = require('express'),
	adminAuthService = require('../../services/admin_apis/admin_authentication');

let router = express.Router();

/* USER LOGIN */
// router.post('/user/login', userAuthService.userLogin);

/* ADMIN LOGIN */
router.post('/admin/login', adminAuthService.adminLogin);


module.exports = router;
