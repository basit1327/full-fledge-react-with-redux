'use strict';

const
	express = require('express'),
	publicApiService = require('../../services/public_apis')

let router = express.Router();

/*Product APIs */
router.get('/get_header_menu', publicApiService.getHeaderMenu);
router.get('/get_featured_boat', publicApiService.getFeaturedBoats);
router.get('/get_latest_news', publicApiService.getLatestNews);
router.get('/get_events', publicApiService.getEvents);
router.get('/get_event_by_id', publicApiService.getEventById);
router.get('/get_boat_by_id', publicApiService.getBoatById);
router.get('/get_all_brands', publicApiService.getAllBrands);
router.get('/get_ranges', publicApiService.getRanges);
router.post('/get_boats', publicApiService.getBoats);

module.exports = router;
